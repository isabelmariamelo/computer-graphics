/******************************************
*
* Official Name:  Isabel Melo
*
* Call me: Liz
*
* E-mail: immelo@syr.edu
*
* Assignment:  Assignment 2
*
* Environment/Compiler:  Xcode Version 14.2 (14C18)
*
* Date submitted:  February 27, 2023
*
* References:
 - I used the windowsWithKeyboardOptions.cpp code as a skeleton for this program, however all function names have been modified for the function of this progrma
 - I used the code from windowsWithMouseClickOptions.cpp as a reference for my radioMouseControl function
 - Used code from menus.pptx
 - used code from chatGPT to figure out how to drawSpaghetti using the following prompt: "draw Spaghetti using openGL"
 
 - used this code:  https://web.engr.oregonstate.edu/~mjb/cs550/PDFs/Transparency.2pp.pdf to understand how to make an object transparent utilized only in drawSauces function.

 
* Interactions:   what happens for which key inputs, mouse clicks, etc For example
*
*                 Right click in food display window for pop-up menu
*                 Click on radio buttons on "menu window" to see display on food window change accordingly
*
 Special Keyboard Interacionts:
 Up arrow: (on food display window) will rotate the dish clockwise -- keep clicking to increment
 Down arrow: (on food display window) will rotate the dish counterclockwise -- keep clicking to increment
 
 keyboard interactions:
 a - display spaghetti
 b - display penne
 c - display ravioli
 d - display farfalle
 
 1- display marinara sauce
 2-display alfredo sauce
 3-display pesto sauce
 4-display vodka sauce
 
 5-display meatballs
 6-display chicken
 7-display mushrooms
 8-display spinach
 9-display parmigiano
*
*
*******************************************/

//reminder: add rotation and you can submit

#include <cmath>
#include <iostream>

#ifdef __APPLE__
#include <GLUT/glut.h>
#else
#include <GL/glut.h>
#endif

#define PI 3.14159265

using namespace std;

// Globals.
static int menuWindow, dishWindow; // Window identifiers.
int isRed=1;  //1 is true
int isBlue=1;

float pastaColor[3] = {0.97, 0.87, 0.68};
float dishColor[] = {0.5,0.5,0.5};

// t or f for pasta selection
float selectSpa = 0;
float selectPen = 0;
float selectRav = 0;
float selectFar = 0;

//t or f for sauce selection
float selectMar = 0;
float selectAlf = 0;
float selectPes = 0;
float selectVod = 0;

//t or f for toppings
float selectMeat = 0;
float selectChick = 0;
float selectMush = 0;
float selectSpin = 0;
float selectParm = 0;

//to toggle dish shape, 0 for bowl, 1 for square
int dishShape = 0;

//rotation of plate 0=reset; 180 = clockwise; -180 = counterclockwise
int rotation = 0;

int sqWHeight=500;
int sqWWidth=500;
int circWHeight=500;
int circWWidth=500;
static long font = (long)GLUT_BITMAP_HELVETICA_18;
static long subFont = (long)GLUT_BITMAP_HELVETICA_12;
static long ristoranteFont = (long)GLUT_BITMAP_TIMES_ROMAN_24;

void writeBitmapString(void *font, const char *string)
{
   const char *c;

   for (c = string; *c != '\0'; c++) glutBitmapCharacter(font, *c);
}

void redisplay(void){
    glutSetWindow( menuWindow );
    glutPostRedisplay();  // Update screen with new rotation data
    glutSetWindow( dishWindow );
    glutPostRedisplay();
}

//draws (1pt w) circles at the given x and y position
void drawRadioButtons(float x, float y, float z){
    float angle;
    int i;
    
    if(z==1){
        glBegin(GL_POLYGON);
    }
    else{
        //glBegin(GL_FILL);
        glBegin(GL_LINE_LOOP);
    }
    for(i = 0; i < 30; ++i)
    {
       angle = 2 * PI * i / 30;
       glVertex2f(x + cos(angle) , y + sin(angle));
    }
    
    glEnd();
    
}

//draws checkboxes
void drawCheckBoxes(float x, float y, float z){
    if(z==1){
        glPolygonMode( GL_FRONT_AND_BACK, GL_LINE );
        glBegin(GL_TRIANGLE_STRIP);
        glVertex2f(x+1, y+1);
        glVertex2f(x-1, y+1);
        glVertex2f(x-1, y-1);
        glVertex2f(x+1, y-1);
        glEnd();
        glPolygonMode( GL_FRONT_AND_BACK, GL_FILL );
    }
    glBegin(GL_LINE_LOOP);
    glVertex2f(x+1, y+1);
    glVertex2f(x-1, y+1);
    glVertex2f(x-1, y-1);
    glVertex2f(x+1, y-1);
    glEnd();
    
}

void drawSquarePlate(void){
    glColor3f(dishColor[0], dishColor[1], dishColor[2]); //gray
    glBegin(GL_POLYGON);
    glVertex3f(40,40, 0);
    glVertex3f(-40,40, 0);
    glVertex3f(-40,-40, 0);
    glVertex3f(40,-40, 0);
    glEnd();
    glColor3f(0,0,0);
    glBegin(GL_LINE_LOOP);
    glVertex3f(30,30, 0);
    glVertex3f(-30,30, 0);
    glVertex3f(-30,-30, 0);
    glVertex3f(30,-30, 0);
    glEnd();
}

void drawPlate(void){
    float angle;
    int i;
    glColor3f(dishColor[0], dishColor[1], dishColor[2]); //gray
    glBegin(GL_POLYGON);
    for(i = 0; i < 30; ++i)
    {
       angle = 2 * PI * i / 30;
       glVertex3f( 40*cos(angle) ,  40*sin(angle), 0);
    }
    
    glEnd();
    glColor3f(0,0,0); //black
    glLineWidth(2.0);
    glBegin(GL_LINE_LOOP);
    for(i = 0; i < 30; ++i)
    {
       angle = 2 * PI * i / 30;
       glVertex3f(30*cos(angle) ,  30*sin(angle), 0);
    }
    glEnd();
    glBegin(GL_LINE_LOOP);
    for(i = 0; i < 30; ++i)
    {
       angle = 2 * PI * i / 30;
       glVertex3f( 40*cos(angle) ,  40*sin(angle), 0);
    }
    glEnd();
}

//copied code starts here
//code taken from openGL
void drawSpaghetti(float x, float y, float z){
    glLineWidth(3.0);
    glColor3f(pastaColor[0], pastaColor[1], pastaColor[2]);
    glBegin(GL_LINE_STRIP);
       for (int i = 0; i < 350; i++) {
           // add a displacement (between -2.5 and 2.5) to the current x and y vertex
           x += 5.0 * ((GLfloat) rand() / RAND_MAX - 0.5);
           y += 5.0 * ((GLfloat) rand() / RAND_MAX - 0.5);
           // make sure this new vertex is within the bounds of the plate
           x = max((20.0f-50.0f), min(30.0f, x));
           y = max((20.0f-50.0f), min(30.0f, y));
           glVertex3f(x, y, 0);
       }
       glEnd();
    
}
//copied code ends here

void drawRavioli(float x, float y) {
    glColor3f(pastaColor[0], pastaColor[1], pastaColor[2]);
    glBegin(GL_POLYGON);
    glVertex3f(x+5, y+5, 0);
    glVertex3f(x-5, y+5, 0);
    glVertex3f(x-5, y-5, 0);
    glVertex3f(x+5, y-5, 0);
    glEnd();
    glColor3f(pastaColor[0]-0.2, pastaColor[1]-0.2, pastaColor[2]-0.2);
    glBegin(GL_LINE_LOOP);
    glVertex3f(x+3.5, y+3.5, 0);
    glVertex3f(x-3.5, y+3.5, 0);
    glVertex3f(x-3.5, y-3.5, 0);
    glVertex3f(x+3.5, y-3.5, 0);
    glEnd();
    glColor3f(pastaColor[0]-0.2, pastaColor[1]-0.2, pastaColor[2]-0.2);
    glBegin(GL_LINE_LOOP);
    glVertex3f(x+5, y+5, 0);
    glVertex3f(x-5, y+5, 0);
    glVertex3f(x-5, y-5, 0);
    glVertex3f(x+5, y-5, 0);
    glEnd();
 
}

void drawFarfalleHorizontal(float x, float y){
    glColor3f(pastaColor[0], pastaColor[1], pastaColor[2]);
    glBegin(GL_TRIANGLES);
    glVertex3f(x+5, y+5, 0);
    glVertex3f(x-5, y+5, 0);
    glVertex3f(x,y,0);
    glVertex3f(x,y,0);
    glVertex3f(x-5, y-5, 0);
    glVertex3f(x+5, y-5, 0);
    glEnd();
    glColor3f(pastaColor[0]-0.2, pastaColor[1]-0.2, pastaColor[2]-0.2);
    glBegin(GL_LINE_LOOP);
    glVertex3f(x+5, y+5, 0);
    glVertex3f(x-5, y+5, 0);
    glVertex3f(x,y,0);
    glEnd();
    glBegin(GL_LINE_LOOP);
    glVertex3f(x,y,0);
    glVertex3f(x-5, y-5, 0);
    glVertex3f(x+5, y-5, 0);
    glEnd();
}

void drawFarfalleVertical(float x, float y){
    glColor3f(pastaColor[0], pastaColor[1], pastaColor[2]);
    glBegin(GL_TRIANGLES);
    glVertex3f(x+5, y+5, 0);
    glVertex3f(x+5, y-5, 0);
    glVertex3f(x,y,0);
    glVertex3f(x,y,0);
    glVertex3f(x-5, y-5, 0);
    glVertex3f(x-5, y+5, 0);
    glEnd();
    glColor3f(pastaColor[0]-0.2, pastaColor[1]-0.2, pastaColor[2]-0.2);
    glBegin(GL_LINE_LOOP);
    glVertex3f(x+5, y+5, 0);
    glVertex3f(x+5, y-5, 0);
    glVertex3f(x,y,0);
    glEnd();
    glBegin(GL_LINE_LOOP);
    glVertex3f(x,y,-1146);
    glVertex3f(x-5, y-5, 0);
    glVertex3f(x-5, y+5, 0);
    glEnd();
}


void drawPenneHorizontal(float x, float y){
    //do
    glColor3f(pastaColor[0], pastaColor[1], pastaColor[2]);
    glBegin(GL_POLYGON);
    glVertex3f(x+7, y+2, 0);
    glVertex3f(x-5, y+2, 0);
    glVertex3f(x-7, y-2, 0);
    glVertex3f(x+5, y-2, 0);
    glEnd();
    glColor3f(pastaColor[0]-0.2, pastaColor[1]-0.2, pastaColor[2]-0.2);
    glBegin(GL_LINE_LOOP);
    glVertex3f(x+7, y+2, 0);
    glVertex3f(x-5, y+2, 0);
    glVertex3f(x-7, y-2, 0);
    glVertex3f(x+5, y-2, 0);
    glEnd();
    
}
void drawPenneVertical(float x, float y){
    //do
    glColor3f(pastaColor[0], pastaColor[1], pastaColor[2]);
    glBegin(GL_POLYGON);
    glVertex3f(x+2, y+7, 0);
    glVertex3f(x-2, y+5, 0);
    glVertex3f(x-2, y-7, 0);
    glVertex3f(x+2, y-5, 0);
    glEnd();
    glColor3f(pastaColor[0]-0.2, pastaColor[1]-0.2, pastaColor[2]-0.2);
    glBegin(GL_LINE_LOOP);
    glVertex3f(x+2, y+7, 0);
    glVertex3f(x-2, y+5, 0);
    glVertex3f(x-2, y-7, 0);
    glVertex3f(x+2, y-5, 0);
    glEnd();
}

void drawItalianTableCloth(){
    glColor3f(0.80,0.12,0.16); //red
    int x[] = {10, 50, 90, 30, 70, 110};
    int y[] = {10, 50, 90, 30, 70, 110};
    for(int i=0; i<3; i++){
        for(int a=0; a<3; a++){
            glBegin(GL_POLYGON);
            glVertex3f(x[i]+10, y[a]+10,-1146);
            glVertex3f(x[i]-10, y[a]+10,-1146);
            glVertex3f(x[i]-10, y[a]-10,-1146);
            glVertex3f(x[i]+10, y[a]-10,-1146);
            glEnd();
            glBegin(GL_POLYGON);
            glVertex3f(x[i+3]+10, y[a+3]+10,-1146);
            glVertex3f(x[i+3]-10, y[a+3]+10,-1146);
            glVertex3f(x[i+3]-10, y[a+3]-10,-1146);
            glVertex3f(x[i+3]+10, y[a+3]-10,-1146);
            glEnd();
        }
    }
}

void drawSauces(void){
    
    if(selectMar == 1){
        // select marinara sauce color
        glColor4f(0.698,0.0941,0.0275,0.3);
    }
    else if(selectAlf == 1){
        // select alfredo sauce color
        glColor4f(0.91,0.93,0.89,0.5);
    }
    else if(selectPes == 1){
        // select pesto sauce color
        glColor4f(0.3765,0.5961,0.4235,0.5);
    }
    else{
        // select vodka color
        glColor4f(0.8922,0.7392,0.7157,0.5);
    }
    //looked up how to make an object transparent: https://web.engr.oregonstate.edu/~mjb/cs550/PDFs/Transparency.2pp.pdf
    //copied code starts here
    glEnable( GL_BLEND );
    glDepthMask( GL_FALSE );
    glBlendFunc( GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA );
    glBegin(GL_POLYGON);
    for(int i = 0; i < 30; ++i)
    {
       float angle = 2 * PI * i / 30;
       glVertex3f(30*cos(angle) , 30*sin(angle), 0);
    }
    glEnd();
    glDepthMask( GL_TRUE );
    glDisable( GL_BLEND );
    //copied code ends here
    
    
}

void drawMeatballs(void){
    glColor3f(0.32, 0.17, 0.17); // meat brown
    glPushMatrix();
    glTranslatef(0,0,3);
    glutSolidSphere(3,10,10);
    glPopMatrix();
    glPushMatrix();
    glTranslatef(-10,-10,3);
    glutSolidSphere(3,10,10);
    glPopMatrix();
    glPushMatrix();
    glTranslatef(15,7,3);
    glutSolidSphere(3,10,10);
    glPopMatrix();
    glPushMatrix();
    glTranslatef(-18,10,3);
    glutSolidSphere(3,10,10);
    glPopMatrix();
    glPushMatrix();
    glTranslatef(15,-20,3);
    glutSolidSphere(3,10,10);
    glPopMatrix();
    glPushMatrix();
    glTranslatef(0,18,3);
    glutSolidSphere(3,10,10);
    glPopMatrix();
}

void drawChicken(){
    float chickPositionsX[] = {3,28-50,63-50,38-50,65-50,0};
    float chickPositionsY[] = {3,38-50,57-50,65-50,45-50,33-50};
    for(int i=0; i<6; i++){
        glColor3f(0.86,0.81,0.47);//chicken color
        glBegin(GL_TRIANGLE_STRIP);
        glVertex3f(chickPositionsX[i]+2,chickPositionsY[i]+5, 0);
        glVertex3f(chickPositionsX[i]+2,chickPositionsY[i]-3, 0);
        glVertex3f(chickPositionsX[i]-2,chickPositionsY[i]+5, 0);
        glVertex3f(chickPositionsX[i]-2,chickPositionsY[i]-3, 0);
        glEnd();
        glColor3f(0.32, 0.17, 0.17); // meat brown
        glBegin(GL_LINE_LOOP);
        glVertex3f(chickPositionsX[i]+2,chickPositionsY[i]+5, 0);
        glVertex3f(chickPositionsX[i]-2,chickPositionsY[i]+5, 0);
        glVertex3f(chickPositionsX[i]-2,chickPositionsY[i]-3, 0);
        glVertex3f(chickPositionsX[i]+2,chickPositionsY[i]-3, 0);
        glEnd();
        glBegin(GL_LINE_LOOP);
        glVertex3f(chickPositionsX[i]+2,chickPositionsY[i]+4, 0);
        glVertex3f(chickPositionsX[i]-2,chickPositionsY[i]+3, 0);
        glEnd();
        glBegin(GL_LINE_LOOP);
        glVertex3f(chickPositionsX[i]+2,chickPositionsY[i]+2, 0);
        glVertex3f(chickPositionsX[i]-2,chickPositionsY[i]+1, 0);
        glEnd();
        glBegin(GL_LINE_LOOP);
        glVertex3f(chickPositionsX[i]+2,chickPositionsY[i], 0);
        glVertex3f(chickPositionsX[i]-2,chickPositionsY[i]-1, 0);
        glEnd();
    }
}

void drawMushrooms(){
    //cout << "drawing your mushrooms"<< endl;
    float mushX[] = {44-50,28-50,63-50,44-50,70-50,44-50};
    float mushY[] = {48-50,50-50,66-50,70-50,45-50,29-50};
    glColor3f(0.84,0.80,0.75);
    for(int i=0; i<6; i++){
        glBegin(GL_POLYGON);
        glVertex3f(mushX[i] + 2,mushY[i] + 2, 0);
        glVertex3f(mushX[i] - 2,mushY[i] + 2, 0);
        glVertex3f(mushX[i] - 2,mushY[i] - 2, 0);
        glVertex3f(mushX[i] + 2,mushY[i] -2, 0);
        glEnd();
        
        glBegin(GL_TRIANGLE_FAN);
        for(int x = 0; x < 30; ++x)
        {
            float angle =  PI * x / 30;
            glVertex3f(mushX[i] + 4*cos(angle) , mushY[i]+2 + 4*sin(angle), 0);
        }
        glEnd();
    }
    
}
void drawSpinach(){
    //cout << "drawing your spinach"<< endl;
    float spiX[] = {55-50,28-50,63-50,44-50,70-50,50-50};
    float spiY[] = {44-50,50-50,66-50,70-50,34-50,22-50};
    glColor3f(0.56,0.60,0.29);
    for(int i=0; i<6; i++){
        glBegin(GL_TRIANGLE_FAN);
        for(int x = 0; x < 30; ++x)
        {
            float angle =  2*PI * x / 30;
            glVertex3f(spiX[i] + 5*cos(angle) , spiY[i] + 2.5*sin(angle), 0);
        }
        glEnd();
    }
    glColor3f(0.36,0.40,0.09);
    for(int i=0; i<6; i++){
        glBegin(GL_LINE_LOOP);
        for(int x = 0; x < 30; ++x)
        {
            float angle =  2*PI * x / 30;
            glVertex3f(spiX[i] + 5*cos(angle) , spiY[i] + 2.5*sin(angle), 0);
        }
        glEnd();
        glBegin(GL_LINE_STRIP);
        glVertex3f(spiX[i] +3 , spiY[i] , 0);
        glVertex3f(spiX[i] -8, spiY[i] , 0);
        glEnd();
    }
    
    
}

// //copied code starts here
//code taken from chatGPT
void drawParm(){ // same code used for spaghettis but this time using GL_POINTS instead of lineF
    float x;
    float y;
    
    glPointSize(3.0);
    
    for (int i = 0; i < 350; i++) {
        // add a displacement (between -2.5 and 2.5) to the current x and y vertex
        x += 5.0 * ((GLfloat) rand() / RAND_MAX - 0.5);
        y += 5.0 * ((GLfloat) rand() / RAND_MAX - 0.5);
        // make sure the x and y values are within the bounds of the plate
        x = max((20.0f-50.0f), min(80.0f-50.0f, x));
        y = max((20.0f-50.0f), min(80.0f-50.0f, y));
        glBegin(GL_POINTS);
        glVertex3f(x, y, 0);
        glEnd();
    }
    
    
}

void drawPlateDisc(float X, float Y, float Z, float R){ // code similar to circularAnnulusesMod.cpp
    float t;
    int i;
    //glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);
    
    glEnable(GL_DEPTH_TEST);
    glBegin(GL_TRIANGLE_STRIP);
       glVertex3f( X, Y, Z);
       for(i = 0; i <= 30; ++i)
       {
          t = 2 * PI * i / 30;
           glColor3f(dishColor[0],dishColor[1],dishColor[2]);
           glVertex3f(X + cos(t) * (R - 10) , Y + (R-10)*sin(t) ,Z);
           glColor3f(0.7,0.7,0.7);
           glVertex3f(X + cos(t) * (R + 3), Y + (R + 3)*sin(t), Z );
           
         
       }
    glEnd();
    glDisable(GL_DEPTH_TEST);
 
}
void generalMenu(int id){
    if(id==1) exit(0);
}

void pastaTypeMenu(int id){
    switch(id){
        case 2:
            cout << "gluten free" <<endl;
            pastaColor[0] = 1;
            pastaColor[1] = 0.97;
            pastaColor[2] = 0.78;
            break;
        case 3:
            cout << "whole grain" << endl;
            pastaColor[0] = 0.78;
            pastaColor[1] = 0.70;
            pastaColor[2] = 0.54;
            break;
        case 4:
            cout << "original" << endl;
            pastaColor[0] = 0.97;
            pastaColor[1] = 0.87;
            pastaColor[2] = 0.69;
        //{0.97, 0.87, 0.68}
            break;
    }
    redisplay();
}

void plateShapeMenu(int id){
    switch(id){
        case 5:
            cout << "bowl" << endl;
            dishShape = 0;
            break;
        case 6:
            cout << "square" << endl;
            dishShape = 1;
            break;
    }
    redisplay();
    
}

void plateColorMenu(int id){
    switch(id){
        case 7:
            cout << "gray" << endl;
            dishColor[0] = 0.5;
            dishColor[1] = 0.5;
            dishColor[2] = 0.5;
            
            break;
        case 8:
            cout << "black" << endl;
            dishColor[0] = 0;
            dishColor[1] = 0;
            dishColor[2] = 0;
            break;
        case 9:
            cout << "white" << endl;
            dishColor[0] = 1;
            dishColor[1] = 1;
            dishColor[2] = 1;
            break;
    }
    redisplay();
}

void rotationMenu(int id){
    switch(id){
        case 1:
            cout << "clockwise (up arrow key)" << endl;
            rotation += 15;
            redisplay();
            break;
        case 2:
            cout << "counterclockwise (down arrow key)" << endl;
            rotation -= 15;
            redisplay();
            break;
        case 3:
            cout << "reset" << endl;
            rotation = 0;
            redisplay();
            break;
    }
}

void generateGeneralMenu(){
    // The sub-menu is created first (because it should be visible when the top
    // menu is created): its callback function is registered and menu entries added.
    int pastaMenu;
    pastaMenu = glutCreateMenu(pastaTypeMenu);
    glutAddMenuEntry("gluten free", 2);
    glutAddMenuEntry("whole grain",3);
    glutAddMenuEntry("original",4);
    
    int plateMenu;
    plateMenu = glutCreateMenu(plateShapeMenu);
    glutAddMenuEntry("bowl",5);
    glutAddMenuEntry("square plate",6);
    
    int plateColorSub;
    plateColorSub = glutCreateMenu(plateColorMenu);
    glutAddMenuEntry("gray",7);
    glutAddMenuEntry("black",8);
    glutAddMenuEntry("white",9);
    
    int rotationSubMenu;
    rotationSubMenu = glutCreateMenu(rotationMenu);
    glutAddMenuEntry("clockwise", 1);
    glutAddMenuEntry("counterclockwise",2);
    glutAddMenuEntry("reset",3);
    // The top menu is created: its callback function is registered and menu entries,
    // including a submenu, added.
    glutCreateMenu(generalMenu);
    glutAddSubMenu("Pasta Type", pastaMenu);
    glutAddSubMenu("Plate Shape", plateMenu);
    glutAddSubMenu("Plate Color", plateColorSub);
    glutAddSubMenu("Rotate Plate", rotationSubMenu);
    glutAddMenuEntry("Quit",1);

    // The menu is attached to a mouse button.
    glutAttachMenu(GLUT_RIGHT_BUTTON);
}

//similar to windowsWMouseClickOptions.cpp
void radioMouseControl(int button, int state, int x, int y)
{
    int xWorld, yWorld;
    if (button == GLUT_LEFT_BUTTON && state == GLUT_DOWN)
    {
        xWorld=x/5;
        yWorld=(500 - y)/5;
        
        //pasta selection
        int pastaXMin = 12;
        int spaYMin = 65;
        int penYMin = spaYMin - 5;
        int ravYMin = penYMin -5;
        int farYMin = ravYMin - 5;
        
        if (xWorld>= pastaXMin && xWorld<= pastaXMin+1 && yWorld>= spaYMin && yWorld<=spaYMin+1){
            selectSpa =! selectSpa;
            selectPen = 0;
            selectRav = 0;
            selectFar = 0;
            cout<<"selected spaghetti"<<endl;
            redisplay();
        }
        
        else if(xWorld>= pastaXMin && xWorld<= pastaXMin+1 && yWorld>=penYMin && yWorld<=penYMin+1){
            selectSpa = 0;
            selectPen =! selectPen;
            selectRav = 0;
            selectFar = 0;
            cout<<"selected penne"<<endl;
            redisplay();
        }
        else if(xWorld>= pastaXMin && xWorld<= pastaXMin+1 && yWorld>=ravYMin && yWorld<=ravYMin+1){
            selectSpa = 0;
            selectPen = 0;
            selectRav =! selectRav;
            selectFar = 0;
            cout<<"selected ravioli"<<endl;
            redisplay();
        }
        else if(xWorld>= pastaXMin && xWorld<= pastaXMin+1 && yWorld>=farYMin && yWorld<=farYMin+1){
            selectSpa = 0;
            selectPen = 0;
            selectRav = 0;
            selectFar =! selectFar;
            cout<<"selected farfalle"<<endl;
            redisplay();
        }
        else{
            //redisplay();
        }
        
        //sauce selection
        int sauceXMin = pastaXMin + 45;
        
        if (xWorld>= sauceXMin && xWorld<= sauceXMin+1 && yWorld>= spaYMin && yWorld<=spaYMin+1){
             selectMar =! selectMar;
             selectAlf = 0;
             selectPes = 0;
             selectVod = 0;
            cout<<"selected marinara"<<endl;
            redisplay();
        }
        
        else if(xWorld>= sauceXMin && xWorld<= sauceXMin+1 && yWorld>=penYMin && yWorld<=penYMin+1){
            selectMar = 0;
            selectAlf =! selectAlf;
            selectPes = 0;
            selectVod = 0;
            cout<<"selected alfredo"<<endl;
            redisplay();
        }
        else if(xWorld>= sauceXMin && xWorld<= sauceXMin+1 && yWorld>=ravYMin && yWorld<=ravYMin+1){
            selectMar = 0;
            selectAlf = 0;
            selectPes =! selectPes;
            selectVod = 0;
            cout<<"selected pesto"<<endl;
            redisplay();
        }
        else if(xWorld>= sauceXMin && xWorld<= sauceXMin+1 && yWorld>=farYMin && yWorld<=farYMin+1){
            selectMar = 0;
            selectAlf = 0;
            selectPes = 0;
            selectVod =! selectVod;
            cout<<"selected vodka"<<endl;
            redisplay();
        }
        else{
            //redisplay();
        }
        
        int topXMin = (sauceXMin + pastaXMin)/2 - 5;
        int meatYMin = farYMin - 15;
        int chickYMin = meatYMin - 5;
        int mushYMin = chickYMin - 5;
        int spiYMin = mushYMin - 5;
        int parmYMin = spiYMin - 5;
        
        if(xWorld>= topXMin && xWorld<= topXMin+1 && yWorld>=meatYMin && yWorld<=meatYMin+1){
            cout << "selected meat" << endl;
            selectMeat =! selectMeat;
            redisplay();
        }
        
        if(xWorld>= topXMin && xWorld<= topXMin+1 && yWorld>=chickYMin && yWorld<=chickYMin+1){
            cout << "selected chicken" << endl;
            selectChick =! selectChick;
            redisplay();
        }
        if(xWorld>= topXMin && xWorld<= topXMin+1 && yWorld>=mushYMin && yWorld<=mushYMin+1){
            cout << "selected mushrooms" << endl;
            selectMush =! selectMush;
            redisplay();
        }
        
        if(xWorld>= topXMin && xWorld<= topXMin+1 && yWorld>=spiYMin && yWorld<=spiYMin+1){
            cout << "selected spinach" << endl;
            selectSpin =! selectSpin;
            redisplay();
        }
        if(xWorld>= topXMin && xWorld<= topXMin+1 && yWorld>=parmYMin && yWorld<=parmYMin+1){
            cout << "selected parm" << endl;
            selectParm =! selectParm;
            redisplay();
        }
        
    }
    
}


// Drawing routine for first window.
void drawSceneMenu(void){
   // Choose window.
   glutSetWindow(menuWindow);
    glClear(GL_COLOR_BUFFER_BIT);
    glColor3f(0.0, 0.0, 0.0);
    //main title
    glRasterPos3f(27,85, 0.0);
    writeBitmapString((void*)ristoranteFont, "Build Your Own Pasta");
    
    //pasta
    int pastaX = 10;
    int pastaY = 70;
    glRasterPos3f(pastaX,pastaY, 0.0);
    writeBitmapString((void*)font, "Pick One Pasta");
    glRasterPos3f(pastaX+=5,pastaY-=5, 0.0);//15,65
    drawRadioButtons(pastaX-2,pastaY+1,selectSpa);//13/66
    writeBitmapString((void*)subFont, "Spaghetti (a)");
    glRasterPos3f(pastaX,pastaY-=5, 0.0);
    drawRadioButtons(pastaX-2,pastaY+1,selectPen);
    writeBitmapString((void*)subFont, "Penne (b)");
    glRasterPos3f(pastaX,pastaY-=5, 0.0);
    drawRadioButtons(pastaX-2,pastaY+1,selectRav);
    writeBitmapString((void*)subFont, "Ravioli (c)");
    glRasterPos3f(pastaX,pastaY-=5, 0.0);
    drawRadioButtons(pastaX-2,pastaY+1,selectFar);
    writeBitmapString((void*)subFont, "Farfalle (d)");
    
    //sauce
    int sauceX = pastaX + 40;
    int sauceY = 70;
     glRasterPos3f(sauceX ,sauceY, 0.0);
     writeBitmapString((void*)font, "Pick One Sauce");
     glRasterPos3f(sauceX +=5 ,sauceY-=5, 0.0);
     writeBitmapString((void*)subFont, "Marinara (1)");
     drawRadioButtons(sauceX-2,sauceY+1,selectMar);
     glRasterPos3f(sauceX ,sauceY-=5, 0.0);
     writeBitmapString((void*)subFont, "Alfredo (2)");
    drawRadioButtons(sauceX-2,sauceY+1,selectAlf);
     glRasterPos3f(sauceX ,sauceY-=5, 0.0);
     writeBitmapString((void*)subFont, "Pesto (3)");
     drawRadioButtons(sauceX-2,sauceY+1,selectPes);
     glRasterPos3f(sauceX ,sauceY-=5, 0.0);
     writeBitmapString((void*)subFont, "Vodka (4)");
     drawRadioButtons(sauceX-2,sauceY+1,selectVod);

    //toppings
    int toppingsX = ((sauceX + pastaX)/2)-10;
    int toppingsY = sauceY - 10;
    glRasterPos3f(toppingsX ,toppingsY, 0.0);
    writeBitmapString((void*)font, "Choose Some Toppings");
    glRasterPos3f(toppingsX +=5 ,toppingsY-=5, 0.0);
    writeBitmapString((void*)subFont, "Meatballs (5)");
    drawCheckBoxes(toppingsX-2,toppingsY+1,selectMeat);
    glRasterPos3f(toppingsX ,toppingsY-=5, 0.0);
    writeBitmapString((void*)subFont, "Chicken (6)");
    drawCheckBoxes(toppingsX-2,toppingsY+1,selectChick);
    glRasterPos3f(toppingsX ,toppingsY-=5, 0.0);
    writeBitmapString((void*)subFont, "Mushrooms (7)");
    drawCheckBoxes(toppingsX-2,toppingsY+1,selectMush);
    glRasterPos3f(toppingsX ,toppingsY-=5, 0.0);
    writeBitmapString((void*)subFont, "Spinach (8)");
    drawCheckBoxes(toppingsX-2,toppingsY+1,selectSpin);
    glRasterPos3f(toppingsX ,toppingsY-=5, 0.0);
    writeBitmapString((void*)subFont, "Parmigiano (9)");
    drawCheckBoxes(toppingsX-2,toppingsY+1,selectParm);
    

   glFlush();
}

//code not copied but similar to one found in teapot.cpp
void drawTeapot(){
    glColor3f(1,1,1);
    glPushMatrix();
    glTranslatef(10,10,-1146);
    glutWireTeapot(5.0);
    glPopMatrix();
}


// Drawing routine for second window.
void drawSceneDishWindow(void)
{
   // Choose window.
   glutSetWindow(dishWindow);

    glClear(GL_COLOR_BUFFER_BIT |GL_DEPTH_BUFFER_BIT);
    drawItalianTableCloth();
    drawTeapot();
    glColor3f(0.0, 0.0, 0.0); // background color white
    glPushMatrix();
    glTranslatef(50,50,-1146);
    glRotatef(rotation,0,0,-50);
    if(dishShape == 0){
        drawPlate();
    }
    if(dishShape == 1){
        drawSquarePlate();
    }
    if(selectSpa == 1){
        drawSpaghetti(30-50,30-50,0);
        drawSpaghetti(35-50,35-50,0);
        drawSpaghetti(0,0,0);
        drawSpaghetti(-5,-5,0);
        drawSpaghetti(5,5,0);
        drawSpaghetti(-10,-10,0);
        drawSpaghetti(10,10,0);
        drawSpaghetti(15,15,0);
    }
    if(selectPen == 1){
        drawPenneHorizontal(0,0);
        for(int i=0; i< 20; i++){
            drawPenneHorizontal((rand() % 40)-20, (rand() % 40-20) );
        }
        for(int i=0; i< 20; i++){
            drawPenneVertical((rand() % 40)-20, (rand() % 40)-20 );
        }
    }
    if(selectRav == 1){
        for(int i=0; i< 40; i++){
            drawRavioli((rand() % 40) -20, (rand() % 40) -20);
        }
    }
    if(selectFar == 1){
        for(int i=0; i< 40; i++){
            drawFarfalleVertical((rand() % 40) - 20, (rand() % 40) - 20);
            drawFarfalleHorizontal((rand() % 40) - 20, (rand() % 40) -20);
        }
    
    }
    if(selectMar==1 || selectAlf==1 || selectPes==1 || selectVod==1){
        drawSauces();
    }
    
    if(selectMeat == 1){
        drawMeatballs(); //done
    }
    
    if(selectChick== 1){
        drawChicken(); //done
    }
    
    if(selectMush == 1){
        drawMushrooms();
    }
    if(selectSpin == 1){
        drawSpinach();
    }
    if(selectParm == 1){
        glColor3f(0.9808,0.8824,0.6588);
        drawParm();
        drawParm();
        glColor3f(0.9808,0.9824,0.7588);
        drawParm();
        drawParm();
        glColor3f(0.8808,0.7824,0.5588);
        drawParm();
        drawParm();
    }
    if(dishShape == 0){
        drawPlateDisc(0,0,0,40);
    }
    
    
    
    glPopMatrix();

   glFlush();
}


// Initialization routine for first window.
void setupMenuWindow(void)
{
   // White background.
   glClearColor(1.0, 1.0, 1.0, 0.0);
}

// Initialization routine for second window.
void setupDishWindow(void)
{
   // white background.
   glClearColor(1.0, 1.0, 1.0, 0.0);
}

// Reshape routine for first window.
void resizeMenuWindow(int w, int h)
{
   glViewport(0, 0, (GLsizei) w, (GLsizei) h);
   glMatrixMode(GL_PROJECTION);
   glLoadIdentity();

   // Aspect ratio matches the window.
   glOrtho(0.0, 100.0, 0.0, 100.0, -1.0, 1.0);

   glMatrixMode(GL_MODELVIEW);
   glLoadIdentity();
}

// Reshape routine for second window.
void resizeDishWindow(int w, int h)
{

   //glViewport(0, 0, (GLsizei)w, (GLsizei)h);
   glMatrixMode(GL_PROJECTION);
   glLoadIdentity();
    GLdouble vvLeft = 0;
    GLdouble vvRight = 100;
    GLdouble vvBottom = 0;
    GLdouble vvTop = 100;
    GLdouble vvNear = -1.0;
    GLdouble vvFar = 1.0;
    GLdouble vvDepth = vvFar - vvNear;
    GLdouble vvHeight = vvTop - vvBottom;
    GLdouble vvFovRads = 0.0872665;
    vvNear = (vvHeight / 2.0) / tan(vvFovRads / 2.0);
    vvFar = vvNear + vvDepth;
    cout << vvNear << endl;
    cout << vvFar << endl;
    glFrustum(0, 100, 0, 100, vvNear, vvFar);
   glMatrixMode(GL_MODELVIEW);
   glLoadIdentity();
}


// Keyboard input processing routine shared by both windows.
void keyInput(unsigned char key, int x, int y)
{
   switch(key)
   {
      case 27:
         exit(0);
         break;
           //cases for sauce selection
    case 'a':
            selectSpa =! selectSpa;
            selectPen = 0;
            selectRav = 0;
            selectFar = 0;
           //https://community.khronos.org/t/how-to-glutpostredisplay-on-a-window-that-is-not-the-current-window/73556
           redisplay();
           break;
       case 'b':
               selectSpa = 0;
               selectPen =! selectPen;
               selectRav = 0;
               selectFar = 0;
           redisplay();
              break;
       case 'c':
               selectSpa = 0;
               selectPen = 0;
           selectRav =! selectRav;
               selectFar = 0;
           redisplay();
              break;
       case 'd':
               selectSpa = 0;
               selectPen = 0;
           selectRav = 0;
               selectFar =! selectFar;
           redisplay();
              break;
       case '1':
           selectMar =! selectMar;
           selectAlf = 0;
           selectPes = 0;
           selectVod = 0;
           redisplay();
           break;
       case '2':
           selectMar = 0;
           selectAlf =! selectAlf;
           selectPes = 0;
           selectVod = 0;
           redisplay();
           break;
       case '3':
           selectMar = 0;
           selectAlf = 0;
           selectPes =! selectPes;
           selectVod = 0;
           redisplay();
           break;
       case '4':
           selectMar = 0;
           selectAlf = 0;
           selectPes = 0;
           selectVod =! selectVod;
           redisplay();
           break;
       case '5':
           selectMeat=!selectMeat;
           redisplay();
           break;
       case '6':
           selectChick=!selectChick;
           redisplay();
           break;
       case '7':
           selectMush=!selectMush;
           redisplay();
           break;
       case '8':
           selectSpin=!selectSpin;
           redisplay();
           break;
       case '9':
           selectParm=!selectParm;
           redisplay();
           break;
      default:
         break;
   }
}

void specialKeyInput(int key, int x, int y){
    switch(key){
        case GLUT_KEY_DOWN:
            rotation -= 15;
            redisplay();
            break;
        case GLUT_KEY_UP:
            rotation += 15;
            redisplay();
            break;
    }
}

// Routine to output interaction instructions to the C++ window.
void printInteraction(void)
{
    cout << "Mouse Interactions" << endl;
    cout << "Click on radio buttons in menu window to see your dish appear." << endl;
    cout << "" << endl;
    cout << "Special Keyboard Interactions:" << endl;
    cout << "Up arrow: (on food display window) will rotate the dish clockwise -- keep clicking to increment" << endl;
    cout << " Down arrow: (on food display window) will rotate the dish counterclockwise -- keep clicking to increment" << endl;
    cout << "" << endl;
    cout << "keyboard interactions:" << endl;
    cout << "a - display spaghetti" << endl;
    cout << "b - display penne" << endl;
    cout << "c - display ravioli" << endl;
    cout << "d - display farfalle" << endl;
    cout << "" << endl;
    cout << "1- display marinara sauce" << endl;
    cout << "2-display alfredo sauce" << endl;
    cout << "3-display pesto sauce" << endl;
    cout << "4-display vodka sauce" << endl;
    cout << "" << endl;
    cout << "5-display meatballs" << endl;
    cout << "6-display chicken" << endl;
    cout << "7-display mushrooms" << endl;
    cout << "8-display spinach" << endl;
    cout << "9-display parmigiano" << endl;
    
}

// Main routine.
int main(int argc, char **argv)
{
   printInteraction();
   glutInit(&argc, argv);
   glutInitDisplayMode (GLUT_SINGLE | GLUT_RGB | GLUT_DEPTH);
   
   // First top-level window definition.
    //Setting up the window with the square
   glutInitWindowSize(sqWWidth, sqWHeight);
   glutInitWindowPosition(100, 100);

   // Create the first window and return id.
   menuWindow = glutCreateWindow("food selection window");

   // Initialization, display, and other routines of the first window.
   setupMenuWindow();
   glutDisplayFunc(drawSceneMenu);
   glutReshapeFunc(resizeMenuWindow);
   glutMouseFunc(radioMouseControl);
   glutKeyboardFunc(keyInput); // Routine is shared by both windows.
   
   // Second top-level window definition.
    //Setting up the window with the circle
   glutInitWindowSize(circWWidth, circWHeight);
   glutInitWindowPosition(600, 100);
   
   // Create the second window and return id.
   dishWindow = glutCreateWindow("food display window");

   // Initialization, display, and other routines of the second window.
   setupDishWindow();
   glutDisplayFunc(drawSceneDishWindow);
   glutReshapeFunc(resizeDishWindow);
   glutKeyboardFunc(keyInput); // Routine is shared by both windows.
    glutSpecialFunc(specialKeyInput); // Routine only valid in dish window
    generateGeneralMenu();
   glutMainLoop();

   return 0;
}
