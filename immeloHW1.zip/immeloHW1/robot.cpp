
/******************************************
*
* Official Name:  Isabel Melo
*
* Call me: Liz
*
* E-mail:  immelo@syr.edu
*
* Assignment:  Assignment 1
*
* Environment/Compiler:  Xcode Version 14.2 (14C18) -- APPLE
*
* Date submitted:  February 8, 2023
*
* References:
 second robot (ollie) inspiration taken from this picture: -https://www.google.com/url?sa=i&url=https%3A%2F%2Fwww.pinterest.com%2Fpin%2F218987600607032846%2F&psig=AOvVaw3OK_gkIHlcbQCDOGFo_L_z&ust=1675707932371000&source=images&cd=vfe&ved=0CA8QjRxqFwoTCIi4y9SA__wCFQAAAAAdAAAAABAD
made some modifications, but the shape is pretty similar.
 
 ///formula used for translate orthogonal  to perspective view https://community.khronos.org/t/converting-from-ortho-to-perspective-view/60362/7
 did not use any code from here, but used the formulas to translate my view
 
 /// idea to use a color array for party mode taken from: https://stackoverflow.com/questions/2898503/background-colour-in-opengl
 this is reflected in my switchBackground() function
 

Ineractions:
 
 ///Press g to make ollie gasp or smile
 
 ///Press y for party time
 
 ///Press p for perspective view

 ///press o for orthogonal view

 ///press d to make Baruch Bot go down

 ///press u to make Baruch Bot go up


*********************/


///////////////////////////////////////////////
// robot.cpp
// Author:  Isabel Melo
//
// This program draws a robot.
//
//
////////////////////////////////////////////////




#include <cmath>
//for sin, cos
#include <iostream>

#include <unistd.h>
#ifdef __APPLE__
#  include <GLUT/glut.h>
#else
#  include <GL/glut.h>
#endif


#define PI 3.14159

using namespace std;

// Globals.
static float cx=20.0, cy=15.0, cz=-1;  //center of base of head
static float ccx=-22.5, ccy=12.5, ccz = -1; //center of base of second robot's head
static float headHeight=5;
static float ollieHeadHeight = 10;
static float ollieHeadWidth = 10;
static float headWidth=5;
static float bodyLength=10.0;
static float neckLength=5;
static float armLength=10;
static float handLength=4;
static float handWidth=4;
static float legHeight=5;
static float legWidth=5;
static float footRadius =2;
static int nv = 10;  //number of vertices for feet
bool gasp = false;
bool yzSwap = false;
static long font = (long)GLUT_BITMAP_8_BY_13;
bool party = false;
bool perspective = true; // true for orthogonal, false for perspective

// copied code from https://stackoverflow.com/questions/2898503/background-colour-in-opengl
GLfloat colors[4][3] = { { 0.0f, 0.0f, 1.0f}, {1.0f, 0.0f, 0.0f }, {0.0f, 1.0f, 0.0f }, {1.0f, 1.0f, 1.0f }};

// above code is copies from https://stackoverflow.com/questions/2898503/background-colour-in-opengl

static int back;
bool up = true;



void drawHead()
{
    glLineWidth(1.0);
    glColor3f(0.0,0.0,0.0); //black
    glBegin(GL_POLYGON);
    glVertex3f(cx-headWidth/2,cy,cz);
    glVertex3f(cx+headWidth/2,cy,cz);
    glVertex3f(cx+headWidth/2,cy+headHeight,cz);
    glVertex3f(cx-headWidth/2,cy+headHeight,cz);
    glEnd();
}

void drawBody()
{
    //draw line for neck, starting at bottom of head,
    //of length neckLength
    glLineWidth(3.0);
    glColor3f(0.0,0.0,0.0); //black
    glBegin(GL_LINES);
    glVertex3f(cx,cy,cz);
    glVertex3f(cx,cy-neckLength,cz);
    glEnd();
    
    //draw line for body
    glLineWidth(7.0);
    glBegin(GL_LINES);
    glVertex3f(cx,cy-neckLength,cz);
    glVertex3f(cx,cy-neckLength-bodyLength,cz);
    glEnd();
    
}



void drawArms()
{
    //draw 2 arms, attached at bottom of neck
    glLineWidth(5.0);
    glColor3f(0.0,0.0,0.0); //black
    glBegin(GL_LINES);
    glVertex3f(cx,cy-neckLength,cz);
    glVertex3f(cx-armLength,cy-neckLength ,cz);
    glVertex3f(cx,cy-neckLength,cz);
    glVertex3f(cx+armLength,cy-neckLength ,cz);
    glEnd();
    //draw hands, triangles at ends of arms
    //left hand (from our view)
    glLineWidth(1.0);  //restore width and color
    glColor3f(0.0,0.0,0.0); //black;
    glBegin(GL_LINE_LOOP);
    glVertex3f(cx-armLength,cy-neckLength-handWidth/2. ,cz);
    glVertex3f(cx-armLength,cy-neckLength+handWidth/2. ,cz);
    glVertex3f(cx-armLength-handLength,cy-neckLength ,cz);
    glEnd();
    //right hand (from our view)
    //Notice, this is clockwise, not counterclockwise
    glBegin(GL_LINE_LOOP);
    glVertex3f(cx+armLength,cy-neckLength-handWidth/2. ,cz);
    glVertex3f(cx+armLength,cy-neckLength+handWidth/2. ,cz);
    glVertex3f(cx+armLength+handLength,cy-neckLength ,cz);
    glEnd();
}

void drawLegs()
{
    //draw 2 legs, attached at bottom of body, going out at an angle
    
    glLineWidth(3.0);
    glColor3f(0.0,0.0,0.0); //black
    glBegin(GL_LINES);
    glVertex3f(cx,cy-neckLength-bodyLength,cz); //down at bottom of body
    glVertex3f(cx-legWidth,cy-neckLength-bodyLength-legHeight,cz);
    glVertex3f(cx,cy-neckLength-bodyLength,cz); //down at bottom of body
    glVertex3f(cx+legWidth,cy-neckLength-bodyLength-legHeight,cz);
    glEnd();
}

void drawFeet(float r, float g, float b)
{
    //draw circle feet of given color
    glColor3f(r,g,b);
    //left foot
    float centerx = cx-legWidth;
    float centery = cy-neckLength-bodyLength-legHeight-footRadius;
    int j;
    
    //  //draw circle foot with nv vertices,
    //center (centerx,centery,cz)
    glBegin(GL_TRIANGLE_FAN);
    glVertex3f(centerx,centery,cz);
    for(j = 0; j <= nv; j++)
    {
        glVertex3f(footRadius * cos( (float)(j)/nv * 2*PI ) +centerx,
                   footRadius * sin( (float)(j)/nv * 2*PI )+centery,
                   cz );
    }
    glEnd();
    
    //right foot
    centerx = cx+legWidth;
    //centery same as for left foot
    
    //  //draw circle foot with nv vertices,
    //center (centerx,centery,cz)
    
    glBegin(GL_TRIANGLE_FAN);
    
    glVertex3f(centerx,centery,cz);
    for(j = 0; j <= nv; j++)
    {
        glVertex3f(footRadius * cos( (float)(j)/nv * 2*PI ) +centerx,
                   footRadius * sin( (float)(j)/nv * 2*PI )+centery,
                   cz );
    }
    glEnd();
}

//displaying text
void drawText(void){
    unsigned char string[] = "The quick god jumps over the lazy brown fox.";
    int w;
    w = glutBitmapLength(GLUT_BITMAP_8_BY_13, string);
    glRasterPos2f(0., 0.);
    float x = .5; /* Centre in the middle of the window */
    glRasterPos2f(x - (float) w / 2, 0.);
    glColor3f(1., 0., 0.);
    int len = size(string);
    for (int i = 0; i < len; i++) {
        glutBitmapCharacter(GLUT_BITMAP_8_BY_13, string[i]);
    }
}

//code for second robot starts here

//draw a square for a head
void drawOllieHead(void){
    glLineWidth(1.0);
    glColor3f(0.0,0.5,1.0); //blue
    glBegin(GL_POLYGON);
    glVertex3f(ccx-ollieHeadWidth/2,ccy,ccz);
    glVertex3f(ccx+ollieHeadWidth/2,ccy,ccz);
    glVertex3f(ccx+ollieHeadWidth/2,ccy+ollieHeadHeight,ccz);
    glVertex3f(ccx-ollieHeadWidth/2,ccy+ollieHeadHeight,ccz);
    glEnd();
}

void drawOllieLeftEar(void){
    //draws triangles for left ear
    glLineWidth(1.0);
    glColor3f(1.0,0.5,0.0);//orange
    glBegin(GL_POLYGON);
    //tip
    glVertex3f(ccx+ollieHeadWidth/2+2.5,ccy+5,ccz);
    //touch head
    glVertex3f(ccx+ollieHeadWidth/2,ccy+7.5,ccz);
    //touch head
    glVertex3f(ccx+ollieHeadWidth/2,ccy+2.5,ccz);
    glEnd();
}

void drawOllieRightEar(void){
    //draws triangles for right ear
    glLineWidth(1.0);
    glColor3f(1.0,0.5,0.0);//orange
    glBegin(GL_POLYGON);
    //tip
    glVertex3f(ccx-ollieHeadWidth/2-2.5,ccy+5,ccz);
    //touch head
    glVertex3f(ccx-ollieHeadWidth/2,ccy+7.5,ccz);
    //touch head
    glVertex3f(ccx-ollieHeadWidth/2,ccy+2.5,ccz);
    glEnd();
    
}

void drawOllieEyes(float cx, float cy, float R, float red, float green, float blue){
    //code taken from
    float t=0; // Angle parameter.
   // static float R = 1.5; // Radius of circle.
    static int numVertices = 15; // Number of vertices on circle.
    
    glLineWidth(1.0);
    glColor3f(red, green, blue);
    glFlush();
    glBegin(GL_TRIANGLE_FAN);
        for (int i = 0; i < numVertices; i++)   {
            t += 2 * PI / numVertices;
            glVertex3f(R * cos(t) + cx, R * sin(t) + cy, ccz);//code similar to drawCircle.cpp
            
        }
        glEnd();
    
    //code for cornea outline
    glColor3f(0, 0, 0);
    glFlush();
    glBegin(GL_LINE_LOOP);
        for (int i = 0; i < numVertices; i++)   {
            t += 2 * PI / numVertices;
            glVertex3f(R * cos(t) + cx, R * sin(t) + cy, ccz);//code similar to drawCircle.cpp
            
        }
        glEnd();
}

//draw cylinder for ollie's body
//code taken from both helixmod.cpp and modularanulusses.cpp
void drawDisc(float R, float X, float Y, float Z)
{
   float t;
   int i;
    //glPolygonMode(GL_FRONT, GL_LINE);
   glColor3f(0.0,0.5,1.0); //blue
   glBegin(GL_TRIANGLE_STRIP);
      glVertex3f( X, Y, Z);
      for(i = 0; i <= 4; ++i)
      {
         t = 2 * PI * i / 4;
          glVertex3f(X + cos(t) * R, -Y, Z + sin(t) * R);
          glVertex3f(X + cos(t) * R, Y, Z + sin(t) * R);
        
      }
   glEnd();
}

void makeOllieGasp(bool gasp){
    if(gasp == true){
        //don't draw square... let him gasp
    }
    else{
       // make him smile
        glLineWidth(1.0);
        glColor3f(0.0,0.5,1.0); //blue
        glBegin(GL_POLYGON);
        glVertex3f(ccx-ollieHeadWidth/2,ccy+2.5,ccz);
        glVertex3f(ccx+ollieHeadWidth/2,ccy+2.5,ccz);
        glVertex3f(ccx+ollieHeadWidth/2,ccy+5,ccz);
        glVertex3f(ccx-ollieHeadWidth/2,ccy+5,ccz);
        glEnd();
        
    }
}


void drawOllieButtons(float z){ //taken from squareAnnulus2.cpp
    float h = 10;
    static float colors[5][3] =
    {
        {1.0, 0.0, 0.0},
        {0.0, 1.0, 0.0},
        {0.0, 0.0, 1.0},
        {1.0, 1.0, 0.0},
        {1.0, 0.0, 1.0},
    };
    static float ollieVertices[5][3] =
    {
        {-17.5, h, z},
        {-20, h, z},
        {-22.5, h, z},
        {-25, h, z},
        {-27.5, h, z},
    };
    //glClear(GL_COLOR_BUFFER_BIT);
    glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);
    glPointSize(5.0);
    glBegin(GL_POINTS);
       for(int i = 0; i < 7; ++i)
       {
          glColor3fv(colors[i%5]);
          glVertex3fv(ollieVertices[i%5]);
       }
    glEnd();
    glFlush();

}
void drawOllieButtonsPerspective(float z){ //taken from squareAnnulus2.cpp
    float h = 10;
    static float colors[5][3] =
    {
        {1.0, 0.0, 0.0},
        {0.0, 1.0, 0.0},
        {0.0, 0.0, 1.0},
        {1.0, 1.0, 0.0},
        {1.0, 0.0, 1.0},
    };
    static float ollieVertices[5][3] =
    {
        {-17.5, h, z},
        {-20, h, z},
        {-22.5, h, z},
        {-25, h, z},
        {-27.5, h, z},
    };
    //glClear(GL_COLOR_BUFFER_BIT);
    glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);
    glPointSize(5.0);
    glBegin(GL_POINTS);
       for(int i = 0; i < 7; ++i)
       {
          glColor3fv(colors[i%5]);
          glVertex3fv(ollieVertices[i%5]);
       }
    glEnd();
    glFlush();

}


void makeOllielegs(){
    int oLegLength = 15;
    int oLegWidth = 5;
    
    //left leg
    glLineWidth(1.0);
    glColor3f(0.0,0.5,1.0); //blue
    glBegin(GL_POLYGON);
    glVertex3f(ccx+ollieHeadWidth/2+oLegWidth,ccy-25,ccz);
    glVertex3f(ccx+ollieHeadWidth/2+oLegWidth,ccy-25-oLegLength,ccz);
    glVertex3f(ccx+ollieHeadWidth/2,ccy-25-oLegLength,ccz);
    glVertex3f(ccx+ollieHeadWidth/2,ccy-25,ccz);
    glEnd();
    glLineWidth(1.0);
    glColor3f(0,0,0); //black
    glBegin(GL_LINE_STRIP);
    glVertex3f(ccx+ollieHeadWidth/2+oLegWidth,ccy-25,ccz);
    glVertex3f(ccx+ollieHeadWidth/2+oLegWidth,ccy-25-oLegLength,ccz);
    glVertex3f(ccx+ollieHeadWidth/2,ccy-25-oLegLength,ccz);
    glVertex3f(ccx+ollieHeadWidth/2,ccy-25,ccz);
    glEnd();
    
    //right leg
    glLineWidth(1.0);
    glColor3f(0.0,0.5,1.0); //blue
    glBegin(GL_POLYGON);
    glVertex3f(ccx-ollieHeadWidth/2-oLegWidth,ccy-25,ccz);
    glVertex3f(ccx-ollieHeadWidth/2-oLegWidth,ccy-25-oLegLength,ccz);
    glVertex3f(ccx-ollieHeadWidth/2,ccy-25-oLegLength,ccz);
    glVertex3f(ccx-ollieHeadWidth/2,ccy-25,ccz);
    glEnd();
    glLineWidth(1.0);
    glColor3f(0,0,0); //blue
    glBegin(GL_LINE_STRIP);
    glVertex3f(ccx-ollieHeadWidth/2-oLegWidth,ccy-25,ccz);
    glVertex3f(ccx-ollieHeadWidth/2-oLegWidth,ccy-25-oLegLength,ccz);
    glVertex3f(ccx-ollieHeadWidth/2,ccy-25-oLegLength,ccz);
    glVertex3f(ccx-ollieHeadWidth/2,ccy-25,ccz);
    glEnd();
    
}

void makeOllieArms(){
    int oLegLength = 15;
    int oLegWidth = 5;
    
    //left arm
    glLineWidth(1.0);
    glColor3f(0.0,0.5,1.0); //blue
    glBegin(GL_POLYGON);
    glVertex3f(ccx+ollieHeadWidth/2+oLegWidth+2,ccy-5,ccz);
    glVertex3f(ccx+ollieHeadWidth/2+oLegWidth+2,ccy-5-oLegLength,ccz);
    glVertex3f(ccx+ollieHeadWidth/2+oLegWidth,ccy-5-oLegLength,ccz);
    glVertex3f(ccx+ollieHeadWidth/2+oLegWidth,ccy-5,ccz);
    glEnd();
    glLineWidth(1.0);
    glColor3f(0.0,0,0); //black
    glBegin(GL_LINE_LOOP);
    glVertex3f(ccx+ollieHeadWidth/2+oLegWidth+2,ccy-5,ccz);
    glVertex3f(ccx+ollieHeadWidth/2+oLegWidth+2,ccy-5-oLegLength,ccz);
    glVertex3f(ccx+ollieHeadWidth/2+oLegWidth,ccy-5-oLegLength,ccz);
    glVertex3f(ccx+ollieHeadWidth/2+oLegWidth,ccy-5,ccz);
    glEnd();
    
    //right arm
    glLineWidth(1.0);
    glColor3f(0.0,0.5,1.0); //blue
    glBegin(GL_POLYGON);
    glVertex3f(ccx-ollieHeadWidth/2-oLegWidth-2,ccy-5,ccz);
    glVertex3f(ccx-ollieHeadWidth/2-oLegWidth-2,ccy-5-oLegLength,ccz);
    glVertex3f(ccx-ollieHeadWidth/2-oLegWidth,ccy-5-oLegLength,ccz);
    glVertex3f(ccx-ollieHeadWidth/2-oLegWidth,ccy-5,ccz);
    glEnd();
    glLineWidth(1.0);
    glColor3f(0,0,0); //blue
    glBegin(GL_LINE_LOOP);
    glVertex3f(ccx-ollieHeadWidth/2-oLegWidth-2,ccy-5,ccz);
    glVertex3f(ccx-ollieHeadWidth/2-oLegWidth-2,ccy-5-oLegLength,ccz);
    glVertex3f(ccx-ollieHeadWidth/2-oLegWidth,ccy-5-oLegLength,ccz);
    glVertex3f(ccx-ollieHeadWidth/2-oLegWidth,ccy-5,ccz);
    glEnd();
    
}

void writeBitmapString(void *font, const char *string)
{
   const char *c;

   for (c = string; *c != '\0'; c++) glutBitmapCharacter(font, *c);
}

void drawOllieFeet(float x, float y){
    glPolygonMode( GL_FRONT_AND_BACK, GL_LINE );
    glColor3f(0.84,0.67,0.04); //yellow
    glLineWidth(3.0);
    glBegin(GL_POLYGON);
    glVertex3f(x,y-5,ccz);
    glVertex3f(x-5,y-5,ccz);
    glVertex3f(x-2.5,y,ccz);
    glEnd();
    glPolygonMode( GL_FRONT_AND_BACK, GL_FILL );
}

//draw entire second robot (I named it ollie)
void drawOllie(void){
    drawOllieEyes(ccx,ccy+ollieHeadHeight,2.5,1.0,0.5,0.0); // this is actually the crown
    drawOllieHead(); //box for a head
    drawOllieLeftEar(); //left ear
    drawOllieRightEar(); // right ear
    drawOllieEyes(-20,19,1.5,1,1,1); // right eye
    drawOllieEyes(-25,19,1.5,1,1,1); // left eye
    drawOllieEyes(-20,19,0.5,0,0,0); // right pupil
    drawOllieEyes(-25,19,0.5,0,0,0); // left pupil
    //following lines affect the mouth
    drawOllieEyes(ccx,ccy+2.5,2,1.0,0.753,0.796); // pink part
    makeOllieGasp(gasp); // make it a smile
    drawDisc(10.0,ccx,ccy,ccz);
    makeOllielegs();
    //note: these feet use outline mode
    drawOllieFeet(-27.5,-22.5);
    drawOllieFeet(-12.5,-22.5);
    makeOllieArms();
    drawOllieEyes(-20,0,1.5,0,0,0);
    drawOllieEyes(-25,0,1.5,0,0,0);
    //drawOllieButtons(-2);
    drawOllieButtonsPerspective(-117);
    drawOllieButtons(-2);
    // Write labels.
      glColor3f(0.0, 0.0, 0.0);
      glRasterPos3f(-32.0, 6.0, 0.0);
      writeBitmapString((void*)font, "Hey! I'm Ollie!");
    //only display in frustum
    glRasterPos3f(-32.0, 25.0, -110);
    writeBitmapString((void*)font, "my body is a cylinder :)");
    
    //top of page ortho view
    glRasterPos3f(-20,30, 0.0);
    writeBitmapString((void*)font, "KEEP 'y' pressed for a surprise :p");
    
    //top of page perspective view
    glRasterPos3f(-20,30,-96);
    writeBitmapString((void*)font, "KEEP 'y' pressed for a surprise :p");
      
}

static float vertices[] =
{
    22.5, -17.5, ccz,
    20.0, -17.5, ccz,
    17.5, -20, ccz,
    15.0, -17.5, ccz,
    12.5, -17.5, ccz,
    12.5, -22.5, ccz,
    17.5, -27.5, ccz,
    22.5, -22.5, ccz
};


//taken from squareAnnulus3.cpp
void drawingAVertexArray(){
   
    glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);
    glColor3f(0.784,0.635,0.784); //lilac
    glLineWidth(3.0);
    // Draw square annulus.
    glBegin(GL_TRIANGLE_STRIP);
       // The i th vertex in vertices[] and i th color in colors[] are called together by glArrayElement(i).
       for(int i = 0; i < 10; ++i) glArrayElement(i%8);
    glEnd();
    glFlush();
    glPolygonMode( GL_FRONT_AND_BACK, GL_FILL );
}
    


//drawing routine for Dr. Baruch's provided robot code
void drawBaruchBot(void){
    drawHead();
    drawBody();
    drawArms();
    drawLegs();
    drawFeet(1.0,0.0,0.0);
    // Write labels.
      glColor3f(0.0, 0.0, 0.0);
      glRasterPos3f(13.0, 25.0, 0.0);
      writeBitmapString((void*)font, "I am Baruch Bot");
    // Write labels.
      glColor3f(0.0, 0.0, 0.0);
      glRasterPos3f(2.0, -15.0, 0.0);
      writeBitmapString((void*)font, "I can move if u press u or d");
}


// Drawing routine.
void drawScene(void)
{s
    glClear (GL_COLOR_BUFFER_BIT);
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
    drawBaruchBot();
    drawOllie();
    drawingAVertexArray();
    if(perspective==true){
        glMatrixMode(GL_PROJECTION);
        glLoadIdentity();
        glOrtho(-40, 40.0, -40.0, 40.0, -1.0,20.0);
        glMatrixMode(GL_MODELVIEW);
    }
    else{
        glMatrixMode(GL_PROJECTION);
        glLoadIdentity();
        glFrustum(-40, 40.0, -40.0, 40.0, 96,117);
        //void glFrustum( GLdouble left,GLdouble right, GLdouble bottom, GLdouble top,GLdouble nearVal,GLdouble farVal);
        glMatrixMode(GL_MODELVIEW);
    }
    glutSwapBuffers();
    
}

// Initialization routine.
void setup(void)
{
    //white background
    
    glClearColor(1.0, 1.0, 1.0, 0.0);
    glEnableClientState(GL_VERTEX_ARRAY);
    glVertexPointer(3, GL_FLOAT, 0, vertices);
}

// OpenGL window reshape routine.
void resize(int w, int h)
{
    glViewport(0, 0, (GLsizei)w, (GLsizei)h);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glOrtho(-40, 40.0, -40.0, 40.0, -1.0,20.0);
    glMatrixMode(GL_MODELVIEW);
}

//copied code starts here
void switchBackgroundColor(void){
    /// idea to use a color array taken from: https://stackoverflow.com/questions/2898503/background-colour-in-opengl
    
    if(back==3){
        back =0;
        ccy=12.5;
    }
    else{
        back++;
    }
    if(!up){
        ccy--;
        up=true;
    }
    else{
        ccy++;
        up=false;
    }
    glClearColor(colors[back][0], colors[back][1], colors[back][2], 1.0f);
    glutPostRedisplay();
    glutSwapBuffers();
}
//above copied code from https://stackoverflow.com/questions/2898503/background-colour-in-opengl
// note that this code is severely modified

// Keyboard input processing routine.
void keyInput(unsigned char key, int x, int y)
{
    switch(key)
    {
        case 27:
            exit(0);
            break;
        case 'g':
            if(gasp == true){
                gasp = false;
                cout << "hehe" << endl; //smiling
            }
            else{
                gasp=true;
                cout << "GASP!" << endl; //gasping
            }
            glutPostRedisplay();
            break;
        case 'd': // redraw baruch bot down
            gasp = true;
            cy--;
            glutPostRedisplay();
            break;
        case 'u': // redraw baruch bot up
            gasp = true;
            cy++;
            glutPostRedisplay();
            break;
        case 'o':
            //cout << "orthogonal view" << endl;
            cz = -1;//change z coordinates to fit ortho view in screen
            ccz = -2;
            perspective = true;
            gasp = false;
            glutPostRedisplay();
            break;
        case 'p':
            //cout << "perspective view" << endl;
            cz = -100; // change z coordinates to fit in perspective view screen
            ccz = -117;
            perspective = false;
            gasp = true;
            glutPostRedisplay();
            break;
        case 'y':
            cout << "party!!!!" << endl;
            switchBackgroundColor(); // switch background color and ollie position
            break;
        default:
            break;
    }
}

void printInteractions(void){
    cout<< "HELLO!!"<<endl;
    cout<< "press g to make Ollie Gasp or smile!"<<endl;
    cout<< "press d to make the baruch bot go up"<<endl;
    cout<< "press u to make the baruch bot go up"<<endl;
    cout<< "press o for orthogonal view"<<endl;
    cout<< "press p for perspective view"<<endl;
    cout<< "press y for party mode"<<endl;
}

// Main routine.
int main(int argc, char **argv)
{
    printInteractions();
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB);
    glutInitWindowSize(500, 500);
    glutInitWindowPosition(100, 100);
    glutCreateWindow("IT'S A ROBOT PARTY");
    setup();
    glutDisplayFunc(drawScene);
    glutReshapeFunc(resize);
    glutKeyboardFunc(keyInput);
    glutMainLoop();
    
    return 0;
}
