//
/******************************************
*
* Official Name: Isabel Melo
*
* Call me: Liz
*
* E-mail:  immelo@syr.edu
*
* Assignment:  Assignment 2
*
* Environment/Compiler:  XCode 14.1
*
* Date submitted: March 23, 2023
*
* References:  ChatGPT, homework2 (my own), fromPtoQ.cpp for moving objects framework, but code was heavily modified
 LegoLookAt for framework, but code was heavily modified.
*
* Interactions:   what happens for which key inputs, mouse clicks, etc For example
*                 - click on dragonfly to make it breathe fire
                click on rocks to toggle wire frame view
 
 cout << "Interaction:" << endl;
 cout << "Press esc to quit" << endl;
 cout << "Press d for the dragonfly to fly one time around" << endl;
 cout << "Press r to view the fly route" << endl;
 cout << "Press 1 to view from the north" << endl;
 cout << "Press 2 to view from the south" << endl;
 cout << "Press 3 to view from the east" << endl;
 cout << "Press 4 to view from the west" << endl;
 cout << "Press s to return to original position and view" << endl;
 cout << "Press 0 to stop the dragonfly" << endl;
 cout << "Press (down arrow) to speed down the cloud" << endl;
 cout << "Press (up arrow) to speed up the cloud" << endl;
 cout << "Press (left arrow) to down up the timer" << endl;
 cout << "Press (right arrow) to speed up the timer" << endl;
   cout << "Press a to toggle the view of ROCK A" << endl;
   cout << "Press b to toggle the view of ROCK B" << endl;
   cout << "Press a to toggle the view of ROCK A" << endl;
   cout << "Press f to make the dragonfly breathe fire" << endl;
*
*******************************************/
//


#include <iostream>

#ifdef __APPLE__
#  include <GLUT/glut.h>
#else
#  include <GL/glut.h>
#endif

using namespace std;

//globals
int view = 0;

float offsetX = 0;
float offsetY = 0;

//dragonfly position globals
float dragX = 6;
float dragY = 3;
float dragZ = -5;

float currDragX;
float currDragY;


//more globals
static int t=0;
static int tWing=0;
static int tSwim = 0;
static int tFish=0;
static int tCloud=0;
static float startX, startY, startZ;//starting point for this leg of trip
static float endX, endY, endZ; //ending point for this leg of trip
static float Px=dragX,Py=dragY,Pz=dragZ;
static float Qx=dragX,Qy=dragY+2,Qz=dragZ;
static float Rx=31,Ry=Qy,Rz=15;
static float Sx=1,Sy=Ry,Sz=Rz;
static float Tx=Sx, Ty=Ry, Tz=-40;
static float Vx,Vy,Vz; //vector from P to Q
static float Mx=0,My=0,Mz=0; //partial vector in direction of V

static int leg = 1;
static int fishLeg = 1;
static bool moveFly = false;  //true for ANIMATION
static bool moveWing = false;
static bool breatheFire = false;
static bool selecting = false;
static int wing = 1; //wing is 1 to rotate them up, 2 to rotate them down
static int fish =1;
static float wingYAngle;
static float fishYAngle;




//moving cloud back and forth globals

static float cloudStartX = -20, cloudStartY = -30;
static float cloudEndX = -1, cloudEndY= 15;

static float fishStartX = cloudEndX +20, fishStartY = cloudEndY-20;
static float fishEndX = cloudStartX , fishEndY= cloudStartY;

static float MCx=0,MCy=0; //partial vector in direction of V
static float MFx=0,MFy=0; //partial vector in direction of V
static int cleg = 1;
static int fleg =1;

static bool togglePath = false;

static int upDownTime = 0;
static int leftRightTime = 0;

//toggle wireframe mode
static bool lilyPad = false;
static bool rockA = false;
static bool rockB = false;
static bool rockC = false;

//cooordinates of mouseclick
int clickX, clickY;
bool ROCKA= false;
bool ROCKB = false;
bool ROCKC = false;

void identifyObject(int x, int y)
{
    unsigned char pixel[3];
    glReadPixels(x, y, 1, 1, GL_RGB, GL_UNSIGNED_BYTE, pixel);
    //printed only for demonstration
    cout << "R: " << (int)pixel[0] << endl;
    cout << "G: " << (int)pixel[1] << endl;
    cout << "B: " << (int)pixel[2] << endl;
    cout << endl;
    //clear past picks
    ROCKA=false;
    ROCKB=false;
    ROCKC=false;
    
    if ((int)pixel[0]==128&&(int)pixel[1]==128&&(int)pixel[2]==128)
    {
        ROCKB=!ROCKB;
    }
    else if ((int)pixel[0]==178&&(int)pixel[1]==178&&(int)pixel[2]==178)
    {
        ROCKA=!ROCKA;
    }
    else if ((int)pixel[0]==153&&(int)pixel[1]==153&&(int)pixel[2]==153)
    {
        ROCKC=!ROCKC;
    }
    else if ((int)pixel[0]==58&&(int)pixel[1]==36&&(int)pixel[2]==59)
    {
        breatheFire=!breatheFire;
    }
    
    selecting=false;
    glutPostRedisplay();
}



void setProjection()
{
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    
    gluPerspective(90, 1, 1, 51);
    
    glMatrixMode(GL_MODELVIEW);
   
}

void selectView(void){
    switch(view){
        case 0:
            //from overhead
            gluLookAt(6, 40, -6,
                      6,5,-6,
                      0,0,-1);
            break;
        case 1:
            //from the north
            gluLookAt(6, 3, -38,
                      6,5,-6,
                      0,1,0);
            break;
        case 2:
            
            //from the south
            gluLookAt(10, 0, 30,
                      6,0,-6,
                      0,1,0);
            break;
        case 3:
           
            //from east
            gluLookAt(50, 3, -6,
                      6,5,-6,
                      0,1,0);
            break;
            
        case 4:
            //from west
            gluLookAt(-29, 3, -6,
                       6,5,-6,
                       0,1,0);
            break;
    }
    
}


void btnClick(int button, int state, int x, int y)
{
    //float xWorld, yWorld;
    if (button == GLUT_LEFT_BUTTON && state == GLUT_DOWN && view == 0)
    {
        cout << x << ' '<< y << endl;
        if(x>321 && x<409 && y>354 && y<444){
            cout << "pressed rock A" << endl;
            rockA=!rockA;
            glutPostRedisplay();
        }
        if(x>149 && x<266 && y>353 && y<446){
            cout << "pressed rock B" << endl;
            rockB=!rockB;
            glutPostRedisplay();
        }
        if(x>148 && x<236 && y>36 && y<131){
            cout << "pressed rock C" << endl;
            rockC=!rockC;
            glutPostRedisplay();
        }
        if(x>177 && x<265 && y>240 && y<331){
            cout << "pressed lilypad" << endl;
            lilyPad=!lilyPad;
            if(leg == 1){
                breatheFire=!breatheFire;
            }
            else{
                moveWing = false;
            }
            glutPostRedisplay();
        }
        if(x>219 && x< 418 && y > 200 && y< 418 && leg == 4){
            breatheFire=!breatheFire;
            glutPostRedisplay();
        }
        if(x>186 && x< 379 && y > 410 && y< 420 && leg == 5){
            breatheFire=!breatheFire;
            glutPostRedisplay();
        }
        if(x>180 && x< 200 && y > 60 && y< 420 && leg == 6){
            breatheFire=!breatheFire;
            glutPostRedisplay();
        }
        if(x>180 && x< 220 && y > 60 && y< 300 && leg == 7){
            breatheFire=!breatheFire;
            glutPostRedisplay();
        }
    }
}

void increaseVectorCloud(void)
{
    float cvx=cloudStartX - cloudEndX, cvy=cloudStartY-cloudEndY;
    //check if time for a new leg
    if (tCloud==50 && cleg==1) //go back
    {
        tCloud=0;
        cleg = 2;
        cvx = cloudEndX - cloudStartX;
        cvy = cloudEndY - cloudStartY;
        
    }
    else if (tCloud==50 && cleg ==2) //go forward
    {
        tCloud=0;
        cleg = 1;
        cvx = cloudStartX - cloudEndX;
        cvy = cloudStartY-cloudEndY;
    }
    
    //update partial vector
    tCloud++;
    MCx=tCloud/50.0*cvx ;
    MCy=tCloud/50.0*cvy ;

    glutPostRedisplay();
}

void increaseVectorFish(void)
{
    float cvx=fishStartX - fishEndX, cvy=fishStartY-fishEndY;
    //check if time for a new leg
    if (tSwim==50 && fleg==1) //go back
    {
        tSwim=0;
        cleg = 2;
        cvx = fishEndX - fishStartX;
        cvy = fishEndY - fishStartY;
        
    }
    else if (tSwim==50 && cleg ==2) //go forward
    {
        tSwim=0;
        cleg = 1;
        cvx = fishStartX - fishEndX;
        cvy = fishStartY-fishEndY;
    }
    
    //update partial vector
    tSwim++;
    MFx=tSwim/50.0*cvx ;
    MFy=tSwim/50.0*cvy ;

    glutPostRedisplay();
}

//code for animation taken from code we viewed in class (moveFromPtoQ.cpp)
void assignEndpointsMakeVector(
        float Px, float Py, float Pz,
        float Qx,float Qy, float Qz)
{
    startX=Px;
    startY=Py;
    startZ=Pz;
    endX=Qx;
    endY=Qy;
    endZ=Qz;
    Vx=endX-startX;
    Vy=endY-startY;
    Vz=endZ-startZ;
    
    
}

void increaseVector(void)
{
    float dividend = 10;
    //check if time for a new leg
    if (t==10 && leg==1) //go back
    {
        cout << "in leg 1" << endl;
        t=0;
        leg = 2;
        dividend = 10;
        assignEndpointsMakeVector(Qx,Qy,Qz,Px,Py,Pz);
        offsetX = 0;
        offsetY = 0;
    }
    else if (t==10 && leg ==2) //go forward
    {
        cout << "in leg 2" << endl;
        t=0;
        leg = 3;
        dividend = 10;
        assignEndpointsMakeVector(Px,Py,Pz,Qx,Qy,Qz);
        offsetX = 0;
        offsetY = 0;
    }
    else if (t==10 && leg==3) //go to rock # 1
    {
        cout << "in leg 3" << endl;
        t=0;
        leg = 4;
        dividend = 10;
        assignEndpointsMakeVector(Qx,Qy,Qz,Rx,Ry,Rz);
        offsetX = 0;
        offsetY = 0;
    }
    else if (t==10 && leg ==4) //go to rock # 2
    {
        cout << "in leg 4" << endl;
        t=0;
        leg =5;
        dividend = 10;
        assignEndpointsMakeVector(Rx,Ry,Rz,Sx,Sy,Sz);
        offsetX = 25;
        offsetY = 20;
    }
    else if (t==10 && leg ==5) //go to rock # 3
    {
        cout << "in leg 5" << endl;
        t=0;
        leg =6;
        dividend = 10;
        assignEndpointsMakeVector(Sx,Sy,Sz,Tx,Ty,Tz);
        offsetX = -5;
        offsetY = 20;
    }
    else if (t==10 && leg ==6) //go to lilypad
    {
        cout << "in leg 6" << endl;
        t=0;
        leg =7;
        dividend = 10;
        assignEndpointsMakeVector(Tx,Ty,Tz,Qx,Qy,Qz);
        offsetX = -5;
        offsetY = -35;
    }
    else if (leg ==7 && t==10){
        cout << "in leg 7" << endl;
        leg = 1;
        t = 9;
        assignEndpointsMakeVector(Qx,Qy,Qz,Px,Py,Pz);
        offsetX = 0;
        offsetY = 0;
        moveFly = false;
        moveWing = false;
    }
    //update partial vector
    t++;
    Mx=t/dividend*Vx + offsetX;
    My=t/dividend*Vy ;
    Mz=t/dividend*Vz + offsetY;
    currDragX = Mx;
    currDragY = My;
    //some output for debugging
   // std::cout<< t<<' ' << leg << std::endl;
    std::cout<< Mx << ' ' << My << ' ' << Mz << std::endl;
    
    glutPostRedisplay();
}

void rotateWing(void){
    if(tWing==10 && wing==1){ // move wing up
        wingYAngle = 45;
        tWing=0;
        wing = 2;
    }
    else if(tWing==10 && wing==2){ //move wing down
        wingYAngle = 0;
        tWing=0;
        wing = 1;
    }
    tWing++;
    glutPostRedisplay();
}

void rotateFishTail(void){
    if(tFish==10 && fish==1){ // move wing up
        fishYAngle = fishYAngle+45;
        tFish=0;
        fish = 2;
    }
    else if(tFish==10 && fish==2){ //move wing down
        fishYAngle = fishYAngle-45;
        tFish=0;
        fish = 1;
    }
    tFish++;
    glutPostRedisplay();
}

 //FOR ANIMATION
 void animateDragonfly(int someValue)
 {
 if (moveFly) increaseVector();
 glutTimerFunc(100+leftRightTime, animateDragonfly, 1);
 }

void animateWingFlap(int someValue)
{
if (moveWing) rotateWing();
glutTimerFunc(25+leftRightTime, animateWingFlap, 1);
}

void animateFishTail(int someValue)
{
 rotateFishTail();
glutTimerFunc(25+leftRightTime, animateFishTail, 1);
}

void animateCloud(int someValue)
{
  increaseVectorCloud();
    glutTimerFunc(100+upDownTime, animateCloud, 1);
}

void animateSwim(int someValue)
{
  increaseVectorFish();
  glutTimerFunc(100+upDownTime, animateSwim, 1);
}


//copied code ends here
void drawPath(){
    glEnable(GL_LINE_STIPPLE);
    glLineStipple(2, 0xAAAA); // dotted pattern
    glBegin(GL_LINES);
    glVertex3f(dragX-5, 1, dragZ+5);
    glVertex3f(dragX+20, 1, dragZ+25);
    glEnd();
    glBegin(GL_LINES);
    glVertex3f(dragX+20, 1, dragZ+25);
    glVertex3f(dragX-10, 1, dragZ+25);
    glEnd();
    glBegin(GL_LINES);
    glVertex3f(dragX-10, 1, dragZ+25);
    glVertex3f(dragX-10, 1, dragZ-30);
    glEnd();
    glBegin(GL_LINES);
    glVertex3f(dragX-10, 1, dragZ-30);
    glVertex3f(dragX-5, 1, dragZ+5);
    glEnd();
    glDisable(GL_LINE_STIPPLE);
}

void drawCloud(float centerX, float centerY){
    glColor4f(1,1,1,0.3);
    //inspiration for transparency was taken from previous homework.
    glEnable( GL_BLEND );
    glDepthMask( GL_FALSE );
    glBlendFunc( GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA );
    glPushMatrix();
    glTranslated(centerX,dragY + 5,centerY);
    glutSolidSphere(5,10,10);
    glPopMatrix();
    glPushMatrix();
    glTranslated(centerX +5,dragY + 5,centerY+1);
    glutSolidSphere(5,10,10);
    glPopMatrix();
    glPushMatrix();
    glTranslated(centerX -5,dragY + 5,centerY+1);
    glutSolidSphere(5,10,10);
    glPopMatrix();
    glDepthMask( GL_TRUE );
    glDisable( GL_BLEND );
    
}

void drawFish(float x, float y, float z){
    //fish body
    glColor3f(0.98,0.32,0.03);
    glPushMatrix();
    glTranslated(x,y-10,z);
    glScaled(2,1,1);
    glutSolidSphere(1,10,10);
    glPopMatrix();
    
    //fish tail
    glColor3f(0.98,0.32,0.03);
    glPushMatrix();
    glTranslated(x-3,y-10,z);
    glRotated(90,0,1,0);
    glRotated(fishYAngle, 0, 1, 0);
    glutSolidCone(1,2,10,10);
    glPopMatrix();
    
    
    //fish bubble
    glColor4f(0.21, 0.28, 0.34,0.5);
    glEnable( GL_BLEND );
    glDepthMask( GL_FALSE );
    glBlendFunc( GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA );
    glPushMatrix();
    glTranslated(x,y-6,z);
    glutSolidSphere(5,10,10);
    glPopMatrix();
    glDepthMask( GL_TRUE );
    glDisable( GL_BLEND );
    
   
    
}

void drawDragonFly(float dragonX, float dragonY, float dragonZ){
    
    //draw body
    glColor3f(0.2275,0.1412,0.2314);
    glPushMatrix();
    glTranslated(dragonX,dragonY,dragonZ);
    //glRotated(90,0,1,0);
    glScaled(5, 0.5, 0.5);
    glutSolidSphere(1,10,10);
    glPopMatrix();
    
    //draw head
    glColor3f(0.2275,0.1412,0.2314);
    glPushMatrix();
    glTranslated(dragonX+4,dragonY,dragonZ);
    //glRotated(90,0,1,0);
    glScaled(0.5, 0.5, 0.5);
    glutSolidSphere(1,10,20);
    glPopMatrix();
    
    //draw wings
    glColor3f(0.68,0.85,0.90);
    glPushMatrix();
    glTranslated(dragonX+2,dragonY+0.5 ,dragonZ-1.5);
    glRotated(wingYAngle,1,0,0);
    glRotated(75,0,1,0);
    glScaled(2, 0.5, 0.5);
    glutWireSphere(1,10,5);
    glPopMatrix();
    
    glColor3f(0.68,0.85,0.90);
    glPushMatrix();
    glTranslated(dragonX+2,dragonY+0.5,dragonZ+1.5);
    glRotated(-wingYAngle,1,0,0);
    glRotated(105,0,1,0);
    glScaled(2, 0.5, 0.5);
    glutWireSphere(1,10,5);
    glPopMatrix();
   
    glColor3f(0.68,0.85,0.90);
    glPushMatrix();
    glTranslated(dragonX+1,dragonY+0.5 ,dragonZ-1.5);
    glRotated(wingYAngle,1,0,0);
    glRotated(105,0,1,0);
    glScaled(2, 0.5, 0.5);
    glutWireSphere(1,10,5);
    glPopMatrix();
    
    glColor3f(0.68,0.85,0.90);
    glPushMatrix();
    glTranslated(dragonX+1,dragonY+0.5 ,dragonZ+1.5);
    glRotated(-wingYAngle,1,0,0);
    glRotated(75,0,1,0);
    glScaled(2, 0.5, 0.5);
    glutWireSphere(1,10,5);
    glPopMatrix();
}

void drawRotatingCup(float x, float y,float z){
    glColor3f(1,1,1);
    glPushMatrix();
    glTranslated(x,y-10,z);
    glRotated(-90,1,0,0);
    glutSolidTeapot(4);
    glPopMatrix();
    
}

void drawPondObstacle(float x, float y, float z){
    glPushMatrix();
    glTranslated(x,y-5,z);
    glScaled(2, 0.2, 2);
    glutSolidSphere(4,10,10);
    glPopMatrix();
}


void drawPondObstacleWire(float x, float y, float z){
    glPushMatrix();
    glTranslated(x,y-5,z);
    glScaled(2, 0.2, 2);
    glutWireSphere(4,10,10);
    glPopMatrix();
}

void drawLilyPadOpening(float x, float y, float z){
    glColor3f(0.21, 0.28, 0.34);
    glPushMatrix();
    glTranslated(x,y-4,z-10);
    glScaled(2, 0.2, 2);
    glutSolidCone(2,4,10,10);
    glPopMatrix();
}


void drawFlower(float x, float y, float z){
    /*inspiration from this code was taken from chatgpt: prompt was: Isabel Melo
    can you help me draw a pink pond flower in opengl that sits on top of an object that has the following constraints:

    drawPondObstacleWire(dragX+20,dragY - 1.5,dragZ+25);

    where float dragX = 6;
    float dragY = 3;
    float dragZ = -5;

    and void drawPondObstacle(float x, float y, float z){
        glPushMatrix();
        glTranslated(x,y-5,z);
        glScaled(2, 0.2, 2);
        glutSolidSphere(4,10,10);
        glPopMatrix();
    }

    my perspective is: gluPerspective(90, 1, 1, 51);
    and my view is:  gluLookAt(6, 40, -6,
                          6,5,-6,
                          0,0,-1);*/
    
    
    glPushMatrix(); // save the current transformation matrix
    // move the flower to sit on top of the pond obstacle
    glTranslatef(x, y, z);
    glColor3f(1.0, 0.8, 0.8); // set the color to pink
    for (int i = 0; i < 8; i++) {
        if(i%2 ==0){
            glColor3f(1.0, 0.8, 0.8);
        }
        else{
            glColor3f(0.9, 0.7, 0.7);
        }
        glPushMatrix(); // save the current transformation matrix
        glRotatef(i * 45.0, 0, 1, 0); // rotate the petal around the stem
        glScaled(0.5,1,1);
        glutSolidSphere(3, 32, 32);// create the petal using a solid sphere
        glPopMatrix(); // restore the previous transformation matrix
    }
    glPopMatrix(); // restore the original transformation matrix
}

void drawFlowers(float x, float y, float z){
    glPushMatrix(); // save the current transformation matrix
    // move the flower to sit on top of the pond obstacle
    glTranslatef(x, y, z);
    glColor3f(1.0, 0.8, 0.8); // set the color to pink
    for (int i = 0; i < 8; i++) {
        if(i%2 ==0){
            glColor3f(1.0, 0.8, 0.8);
        }
        else{
            glColor3f(0.9, 0.7, 0.7);
        }
        glPushMatrix(); // save the current transformation matrix
        glRotatef(i * 45.0, 0, 1, 0); // rotate the petal around the stem
        glScaled(0.5,1,1);
        glutSolidSphere(2, 32, 32);// create the petal using a solid sphere
        glPopMatrix(); // restore the previous transformation matrix
    }
    glPopMatrix(); // restore the original transformation matrix
    
    glPushMatrix(); // save the current transformation matrix
    // move the flower to sit on top of the pond obstacle
    glTranslatef(x+4, y, z);
    glColor3f(1.0, 0.8, 0.8); // set the color to pink
    for (int i = 0; i < 8; i++) {
        if(i%2 ==0){
            glColor3f(1.0, 0.8, 0.8);
        }
        else{
            glColor3f(0.9, 0.7, 0.7);
        }
        glPushMatrix(); // save the current transformation matrix
        glRotatef(i * 45.0, 0, 1, 0); // rotate the petal around the stem
        glScaled(0.5,1,1);
        glutSolidSphere(2, 32, 32);// create the petal using a solid sphere
        glPopMatrix(); // restore the previous transformation matrix
    }
    glPopMatrix(); // restore the original transformation matrix
}


void drawFire(float dragonX, float dragonY, float dragonZ){
    if(breatheFire){
        glColor3f(1,0,0);
        glPushMatrix();
        glTranslated(dragonX+6,dragonY,dragonZ);
        glRotated(-90,0,1,0);
        glutSolidCone(1,2,10,10);
        glPopMatrix();
        glColor3f(0.98,0.32,0.03);
        glPushMatrix();
        glTranslated(dragonX+6.5,dragonY,dragonZ+0.5);
        glRotated(-90,0,1,0);
        glRotated(wingYAngle,1,0,0);
        glutSolidCone(0.5,1,10,10);
        glPopMatrix();
        glPushMatrix();
        glTranslated(dragonX+6.5,dragonY,dragonZ-0.5);
        glRotated(-90,0,1,0);
        glRotated(-wingYAngle,1,0,0);
        glutSolidCone(0.5,1,10,10);
        glPopMatrix();
        glColor3f(1,1,0);
        glPushMatrix();
        glTranslated(dragonX+6.5,dragonY,dragonZ);
        glRotated(-90,0,1,0);
        glRotated(wingYAngle,0,1,0);
        glutSolidCone(0.5,1,10,10);
        glPopMatrix();
        
    }
}

// Drawing routine.
void drawShapes(void)
{
    //Clear buffers
   glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    
    //Set Projection
    setProjection();
    
    //Clear Modeview Matrix
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
    selectView();
    //Build model
    glEnable(GL_DEPTH_TEST);
    
    drawFish(MFx,dragY,MFy);
    
    //draw the lilypad
    glColor3f(0.29,0.71,0.31);
    if(lilyPad){
        drawPondObstacleWire(dragX-5, dragY-1.5,dragZ+5);
    }
    else{
        drawPondObstacle(dragX-5, dragY-1.5,dragZ+5);
    }
    drawLilyPadOpening(dragX-5, dragY-1.5,dragZ+5);
    drawFire(Mx,My,Mz);
    drawDragonFly(Mx,My,Mz);
    glColor3f(.7,.7,.7);
    //draw first rock
    if(rockA || ROCKA){
        drawPondObstacleWire(dragX+20,dragY - 1.5,dragZ+25);

    }
    else{
        drawPondObstacle(dragX+20,dragY - 1.5,dragZ+25);
        drawFlower(dragX + 20, dragY -6, dragZ + 25);
    }
    drawRotatingCup(dragX+22,dragY - 1.5,dragZ+27);
    
    //draw second rock
    glColor3f(.5,.5,.5);
    if(rockB || ROCKB){
        drawPondObstacleWire(dragX-10,dragY - 1.5,dragZ+25);
    }
    else{
        drawPondObstacle(dragX-10,dragY - 1.5,dragZ+25);
        drawFlowers(dragX-10,dragY - 6,dragZ+25);
    }
    drawRotatingCup(dragX-11,dragY - 1.5,dragZ+27);
    
    //draw third rock
    glColor3f(.6,.6,.6);
    if(rockC || ROCKC){
        drawPondObstacleWire(dragX-10,dragY - 1.5,dragZ-30);
    }
    else{
        drawPondObstacle(dragX-10,dragY - 1.5,dragZ-30);
        drawFlowers(dragX-10,dragY - 1.5,dragZ-30);
    }
    drawRotatingCup(dragX-10,dragY - 1.5,dragZ-33);
    
    
    drawCloud(MCx,MCy);
   
    
    if(togglePath){
        drawPath();
    }
}
void drawScene(void)
{
    //draw everything to the buffer, but don't display it, to check clicking
    if(selecting)
    {
        drawShapes();
        identifyObject(clickX,clickY);
    }
    //draw everything, possibly with results of clicking
    else
    {
        drawShapes();
        glutSwapBuffers();
    }
}

void mouseControl(int button, int state, int x, int y)
{
    if(state==GLUT_DOWN && button == GLUT_LEFT)
    {   selecting=true;
        clickX=x;
        clickY=500-y; //for mouse vs window coordinates
        glutPostRedisplay();
        
    }
}

// Initialization routine.
void setup(void)
{
   glClearColor(0.21, 0.28, 0.34, 0.0);
   assignEndpointsMakeVector(Px,Py,Pz,Qx,Qy,Qz);
}

// OpenGL window reshape routine.
void resize(int w, int h)
{
   glViewport(0, 0, (GLsizei)w, (GLsizei)h);
    setProjection();
}

// Keyboard input processing routine.
void keyInput(unsigned char key, int x, int y)
{
   switch(key)
   {
      case 27:
         exit(0);
         break;
       case 'd':
           cout << "dragonfly flies one time around" << endl;
           moveFly = true;  //true for ANIMATION
           moveWing = true;
           break;
       case 'r':
           cout << "toggle view of route" << endl;
           togglePath=!togglePath;
           break;
       case '1':
           cout << "north view" << endl;
           view = 1;
           glutPostRedisplay();
           break;
       case '2':
           cout << "south view" << endl;
           view = 2;
           glutPostRedisplay();
           break;
       case '3':
           cout << "east view" << endl;
           view = 3;
           glutPostRedisplay();
           break;
       case '4':
           cout << "west view" << endl;
           view = 4;
           glutPostRedisplay();
           break;
       case 's':
           cout << "go to original setup and time" << endl;
           view = 0;
           moveFly = false;  //true for ANIMATION
           moveWing = false;
           lilyPad = false;
           rockA = false;
           rockB = false;
           rockC = false;
           cleg = 1;
           tCloud = 50;
           leg = 1;
           t = 10;
           std::cout<< Mx << ' ' << My << ' ' << Mz << std::endl;
           Mx = Px-5;
           My = Py;
           Mz = Pz+5;
           offsetX = 0;
           offsetY = 0;
           std::cout<< Mx << ' ' << My << ' ' << Mz << std::endl;
           glutPostRedisplay();
           break;
       case '0':
           cout << "stop dragonfly" << endl;
           moveFly = false;  //true for ANIMATION
           moveWing = false;
           break;
       case 'a':
           cout << "pressed a" << endl;
           rockA=!rockA;
           ROCKA!=ROCKA;
           glutPostRedisplay();
           break;
       case 'b':
           rockB=!rockB;
           ROCKB!=ROCKB;
           glutPostRedisplay();
           break;
       case 'c':
           rockC=!rockC;
           ROCKC=!ROCKC;
           glutPostRedisplay();
           break;
       case 'l':
           lilyPad=!lilyPad;
           glutPostRedisplay();
           break;
       case 'f':
           cout << "breathing fire" << endl;
           breatheFire=!breatheFire;
           glutPostRedisplay();
           break;
      default:
         break;
   }
}

void specialKeyInput(int key, int x, int y){
    switch(key){
        case GLUT_KEY_DOWN:
            cout <<"cloud speed down" << endl;
            upDownTime+=10;
            glutPostRedisplay();
            break;
        case GLUT_KEY_UP:
            cout <<"cloud speed up" << endl;
            upDownTime-=10;
            glutPostRedisplay();
            break;
        case GLUT_KEY_LEFT:
            cout <<"timer function speed down" << endl;
            leftRightTime+=10;
            glutPostRedisplay();
            break;
        case GLUT_KEY_RIGHT:
            cout <<"timer function speed up" << endl;
            leftRightTime-=10;
            glutPostRedisplay();
            break;
    }
}



// Routine to output interaction instructions to the C++ window.
void printInteraction(void)
{
  cout << "Interaction:" << endl;
  cout << "Press esc to quit" << endl;
  cout << "Press d for the dragonfly to fly one time around" << endl;
  cout << "Press r to view the fly route" << endl;
  cout << "Press 1 to view from the north" << endl;
  cout << "Press 2 to view from the south" << endl;
  cout << "Press 3 to view from the east" << endl;
  cout << "Press 4 to view from the west" << endl;
  cout << "Press s to return to original position and view" << endl;
  cout << "Press 0 to stop the dragonfly" << endl;
  cout << "Press (down arrow) to speed down the cloud" << endl;
  cout << "Press (up arrow) to speed up the cloud" << endl;
  cout << "Press (left arrow) to down up the timer" << endl;
  cout << "Press (right arrow) to speed up the timer" << endl;
    cout << "Press a to toggle the view of ROCK A" << endl;
    cout << "Press b to toggle the view of ROCK B" << endl;
    cout << "Press a to toggle the view of ROCK A" << endl;
    cout << "Press f to make the dragonfly breathe fire" << endl;
}

// Main routine.
int main(int argc, char **argv)
{
   glutInit(&argc, argv);
   glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB |GLUT_DEPTH);
   glutInitWindowSize(500, 500);
   glutInitWindowPosition(100, 100);
   glutCreateWindow("delilah the fire-breathing dragonFly");
   setup();
   glutDisplayFunc(drawScene);
   glutReshapeFunc(resize);
   glutMouseFunc(btnClick);
   glutMouseFunc(mouseControl);
   glutKeyboardFunc(keyInput);
   glutSpecialFunc(specialKeyInput);
   glutTimerFunc(5, animateDragonfly, 1);
   glutTimerFunc(5, animateWingFlap, 1);
   glutTimerFunc(5, animateCloud, 1);
   glutTimerFunc(5, animateFishTail, 1);
   glutTimerFunc(5, animateSwim, 1);
   printInteraction();
   glutMainLoop();

   return 0;
}


