/******************************************
*
* Official Name:  Isabel Melo
*
* Call me: Liz
*
* E-mail:  immelo@syr.edu
*
* Assignment:  Assignment 4
*
* Environment/Compiler: XCode 14.2
*
* Date submitted:  April 10, 2023
*
* References:
 //  note: used framework code from walkingAroundForClass.cpp
 //  floor is xz plane, positive y is up.
 //used color picking code fromn MJBballAndTorusLighingAndColorPicking.cpp
 /*
  Color scheme:
  Dark purple: RGB(51%, 0%, 51%)
  Blood red: RGB(80%, 0%, 0%)
  Midnight black: RGB(0%, 0%, 0%)
  Ghostly white: RGB(95%, 95%, 95%)
  Sickly green: RGB(60%, 80%, 50%)
  orange: Red: 100%
         Green: 37.25%
         Blue: 16.08%
  // used chatGPT to create a function that draws a cylinder
  read following book to understand lighting:
  https://www.glprogramming.com/red/chapter05.html#name11
*
* Interactions:

 up arrow - step forward
 down arrow - step backward
 right arrow - turn to the right
 left arrow - turn to the left
 r - reset to standing in the center
 facing 0 degrees.
 d - opens/closes the door
 l - turns on/off the ceiling lamp
 s - opens/closes the window shade
 f - turns off the flashlight
 all object above are clickable!
 go near cauldron to see it glow
 go near table to pick up the flashlight
 right-click for menu options
 
*
*
*******************************************/


//This define is so you can use sprintf
#define _CRT_SECURE_NO_DEPRECATE

#include <iostream>
#include <stdio.h>
#include <cmath>

#ifdef __APPLE__
#  include <GLUT/glut.h>
#else
#  include <GL/glut.h>
#endif

#define PI 3.14159
using namespace std;

static int house, tasks; // Window identifiers.
static float meX=0, meY=0,meZ=0;
static float angle=0;  //angle facing
static float stepsize=1.0;  //step size
static float turnsize=5.0; //degrees to turn
bool isPicking = false;
static int doorState=0; // 0 for closed door, 1 for open door.
static int doorTime = 0;
static int switchState=0; // 0 for lights off, 1 for lights on.
static int shadesState = 0; // 0 for shades down, 1, for shades up
static bool animateShades = false;
static int shadeAmt = 11;
static int shadeTime = 0;
static float m = 0.5; // ambient light intesity
static int flashlightState = 0; // 1 if the flashlight is on in my hand
static int cauldronState = 0; // 1 if the cauldron is glowing
static int initMagic = 0; //1 to animate orb and do magic
static int doorAngle = 0; //85 when open
static bool animateDoor = false;
static int tOrb = 0;
static int orbLeg = 0;

static float endX, endY, endZ; //ending point for this leg of trip
static float Vx, Vy, Vz;
static float Mx=0,My=0,Mz=0; //partial vector in direction of V
static float Px=-3 , Py=-1, Pz=64;
static float Qx=0 , Qy=10, Qz=64;
static float startX= Px, startY=Py, startZ=Pz;//starting point for this leg of trip
//coordinates of point clicked
int xClick=0;
int yClick=0;
int height =0;

//pink spotlight state
static int pinkSpotlightState = 0; // starts only after orb is in cauldron

static int selectOutCome;

static long font = (long)GLUT_BITMAP_TIMES_ROMAN_24;

void redisplay(void){
    glutSetWindow( house );
    glutPostRedisplay();  // Update screen with new rotation data
    glutSetWindow( tasks );
    glutPostRedisplay();
}


void writeBitmapString(void *font, const char *string)
{
   const char *c;

   for (c = string; *c != '\0'; c++) glutBitmapCharacter(font, *c);
}

// Initialization routine.
void setup(void)
{
    glClearColor(0.53, 0.81, 0.92, 0.0); // high noon
   // glClearColor(0.0, 0.0, 0.0, 1.0);
    glEnable(GL_DEPTH_TEST); // Enable depth testing.
    
    //Turn on OpenGL lighting.
    glEnable(GL_LIGHTING);
    
    srand(time(0));
    selectOutCome = rand() % 2 + 1;;
    cout << selectOutCome << endl;

    // Cull back faces.
    //glEnable(GL_CULL_FACE);
    //glCullFace(GL_FRONT_AND_BACK);

}

void setupTask(void){
    glClearColor(1.0, 1.0, 1.0, 0.0);
}

void resizeTask(int w, int h){
    glViewport(0, 0, (GLsizei) w, (GLsizei) h);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();

    // Aspect ratio matches the window.
    glOrtho(0.0, 100.0, 0.0, 100.0, -1.0, 1.0);

    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
}
// OpenGL window reshape routine.
void resize(int w, int h)
{
    glViewport(0, 0, (GLsizei)w, (GLsizei)h);
    height = h;
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluPerspective(120,1,1,100);
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
}

// Routine to draw a stroke character string.
void writeStrokeString(void *font, const char *string)
{
    const char *c;
    for (c = string; *c != '\0'; c++) glutStrokeCharacter(font, *c);
}

void getID(int x, int y)
{
    unsigned char pixel[3];
    glReadPixels(x, y, 1, 1, GL_RGB, GL_UNSIGNED_BYTE, pixel);
    cout << "R: " << (int)pixel[0] << endl;
    cout << "G: " << (int)pixel[1] << endl;
    cout << "B: " << (int)pixel[2] << endl;
    cout << endl;
    
    //red = toggle door
    if(pixel[0]==255 && pixel[1]==0 && pixel[2]==0){
        animateDoor=!animateDoor;
    }
    
    //green = toggle light switch
    else if(pixel[0]==0 && pixel[1]==255 && pixel[2]==0){
        if(switchState == 0){
            switchState =1;
        }
        else{
            switchState = 0;
        }
    }
    
    //blue = toggle shades
    else if(pixel[0]==0 && pixel[1]==0 && pixel[2]==255){
        cout << "toggle shades" << endl;
        animateShades=!animateShades;
    }
   
    

}

void pickFunction(int button, int state, int x, int y)
{
    if (button == GLUT_LEFT_BUTTON && state == GLUT_DOWN);
    {
        isPicking=true;
        xClick=x;
        yClick=height-y;
        cout<<"In pickFunction"<<endl;
        cout<<"xClick="<<xClick<<" yClick="<<yClick<<endl;
        redisplay();
    }
}
void setMaterial(float r, float g, float b){
    // Material property vectors.
    float matAmbAndDif[] = {r,g,b,1};
    float matSpec[] = { 0, 0, 0, 1 };
    float matShine[] = { 0.0 };

    // Material properties of sphere.
    glMaterialfv(GL_FRONT, GL_AMBIENT_AND_DIFFUSE, matAmbAndDif);
    glMaterialfv(GL_FRONT, GL_SPECULAR, matSpec);
    glMaterialfv(GL_FRONT, GL_SHININESS, matShine);
}

void makeSpotlightMaterial(){
    // Material property vectors.
    float matAmbAndDif[] = {1,0.9,0,1};
    float matSpec[] = { 1.0, 1.0, 1,0, 1.0 };
    float matShine[] = { 50.0 };

    // Material properties of sphere.
    glMaterialfv(GL_FRONT, GL_AMBIENT_AND_DIFFUSE, matAmbAndDif);
    glMaterialfv(GL_FRONT, GL_SPECULAR, matSpec);
    glMaterialfv(GL_FRONT, GL_SHININESS, matShine);
}

void drawSpookyGrass(void){
    //glColor4f(0.66,0.56,0.34,1);
    setMaterial(0.66,0.56,0.34);
    glPushMatrix();
    glTranslatef(0,-1,0);
    glScaled(1000,2,1000);
    glutSolidCube(1);
    glPopMatrix();
}

void drawHouseFrame(void){
    //glColor4f(0.357, 0.357,0.357,1);
    setMaterial(0.357, 0.357,0.357);
    //top of door
    glPushMatrix();
    glTranslatef(0.0, 15.0, 40.0);
    glScaled(7.5,4,0.1);
    glutSolidCube(5);
    glPopMatrix();
    //left of door
    glPushMatrix();
    glTranslatef(-10.5, 0, 40.0);
    glScaled(3.3,2,0.1);
    glutSolidCube(5);
    glPopMatrix();
    //right of door
    glPushMatrix();
    glTranslatef(10.5, 0, 40.0);
    glScaled(3.3,2,0.1);
    glutSolidCube(5);
    glPopMatrix();
    //leftWall
    glPushMatrix();
    glTranslatef(18, 20, 64);
    glScaled(0.5,10,48);
    glutSolidCube(1);
    glPopMatrix();
    glPushMatrix();
    glTranslatef(18, 0, 64);
    glScaled(0.5,10,48);
    glutSolidCube(1);
    glPopMatrix();
    glPushMatrix();
    glTranslatef(18, 0, 48);
    glScaled(0.5,50,15);
    glutSolidCube(1);
    glPopMatrix();
    glPushMatrix();
    glTranslatef(18, 0, 80);
    glScaled(0.5,50,15);
    glutSolidCube(1);
    glPopMatrix();
    //rightWall
    setMaterial(0.4, 0.357,0.357);
    glPushMatrix();
    glTranslatef(-18, 0, 64);
    glScaled(0.1,10,10);
    glutSolidCube(5);
    glPopMatrix();
    setMaterial(0.357, 0.357,0.357);
    //backWall
    glPushMatrix();
    glTranslatef(0, 0, 88);
    glScaled(7.75,10,0.1);
    glutSolidCube(5);
    glPopMatrix();
}

void shadesUpMath(void){
    cout << "drawing shades" << endl;
    shadeTime = 10;
    if(shadeAmt>1 && shadeTime ==10){
        shadeAmt--;
        shadeTime = 0;
        cout << "shades drawn: " <<shadeAmt <<endl;
        if(meX>-18 && meX<18 && meZ>40 && meZ< 88){
            m+=0.02;
        }
    }
    else if(shadeTime = 10 && shadeAmt == 1){
        animateShades = false;
        shadeTime = 0;
        shadesState = 1;
        cout << "shades up animation completed" <<endl;
        
    }
    shadeTime++;
    redisplay();
    
}

void shadesDownMath(void){
    shadeTime = 10;
    if( shadeAmt<11 && shadeTime == 10){
        shadeAmt++;
        shadeTime = 0;
        cout << "shades drawn: " <<shadeAmt <<endl;
        if(meX>-18 && meX<18 && meZ>40 && meZ< 88){
            m-=0.02;
        }
    }
    else if(shadeTime == 10 && shadeAmt == 11){
        animateShades = false;
        shadeTime = 0;
        shadesState = 0;
        cout << "shades down animation completed" <<endl;
        
        
        
    }
    shadeTime++;
    redisplay();
  
}

void rollUpShades(int someValue){
    if(shadesState == 0 && animateShades == true){
        shadesUpMath();
    }
    glutTimerFunc(100,rollUpShades,1);
}

void rollDownShades(int someValue){
    if(shadesState == 1 && animateShades == true){
        shadesDownMath();
    }
    glutTimerFunc(100,rollDownShades,1);
}


void doorOpenMath(void){
    cout << "opening door" << endl;
    doorTime = 10;
    if(doorAngle < 90 && doorTime ==10){
        doorAngle+=10;
        cout << "door angle: " << doorAngle<<endl;
        doorTime = 0;
    }
    else if(doorAngle == 90 && doorTime ==10){
        animateDoor = false;
        doorTime = 0;
        doorState = 1;
        cout << "door is open" <<endl;
        
    }
    doorTime++;
    redisplay();
    
}

void doorCloseMath(void){
    cout << "closing door" << endl;
    doorTime = 10;
    if( doorAngle> 0 && doorTime == 10){
        doorAngle-=10;
        doorTime = 0;
    }
    else if(doorTime == 10 && doorAngle == 0){
        animateDoor = false;
        doorTime = 0;
        doorState = 0;
        cout << "door closed" <<endl;
    }
    doorTime++;
    redisplay();
  
}

void openDoor(int someValue){
    if(doorState == 0 && animateDoor == true){
        doorOpenMath();
    }
    glutTimerFunc(100,openDoor,1);
}

void closeDoor(int someValue){
    if(doorState == 1 && animateDoor == true){
        doorCloseMath();
    }
    glutTimerFunc(100,closeDoor,1);
}



void drawShades(void){
    for(int i=0; i<shadeAmt; i++){
        glPushMatrix();
        glTranslatef(17,15-i,64);
        glScaled(0.5,1.5,25);
        glutSolidCube(1);
        glPopMatrix();
    }
}


void drawDoor(void){
    
    glPushMatrix();
    glTranslatef(2.5, 0.0, 40.0);
    glRotatef(doorAngle,0,1,0);
    glTranslatef(-2.5, 0.0, 0.0);
    glScaled(1,2,0.1);
    glutSolidCube(5);
    glPopMatrix();
}

void drawLightSwitch(){
    if(switchState ==0){
        //draw button
        glPushMatrix();
        glTranslatef(-5.0,0.0,41.5);
        glScaled(0.5,0.5,0.2);
        glutSolidSphere(1,10,10);
        glPopMatrix();
    }
    else{
        //draw button
        glPushMatrix();
        glTranslatef(-4.8,0.0,41.5);
        glScaled(0.5,0.5,0.1);
        glutSolidSphere(1,10,10);
        glPopMatrix();
        //draw pressed button
    }
    setMaterial(0,0,0);
    //glColor4f(0,0,0,1);
    //draw switch frame
    glPushMatrix();
    glScaled(1,2,1);
    glTranslatef(-5.0,0.0,41.0);
    glutSolidCube(1);
    glPopMatrix();
    
   
}

void drawTrees(){
   // glColor4f(0.0, 0.0, 0.0, 1.0);
    setMaterial(0,0,0);
    
    
    //inner ring of trees
    for (int theta=0; theta<360; theta+=10)
    {
        //draw tree trunk
        glPushMatrix();
        glTranslatef(5+50*sin(theta*PI/180), 0.0, 64+50*cos(theta*PI/180) );
        glRotatef(theta,0,1,0);
        
        glRotatef(180, 0.0, 1.0, 0.0); //line it up with 0 position
        glScalef(0.025, 0.025, 0.025);
        glScalef(20,500,20);
        glutSolidCube(1);
        
        glPopMatrix();
        //draw tree leaves
        glPushMatrix();
        glTranslatef(5+50*sin(theta*PI/180), 5.0, 64+50*cos(theta*PI/180) );
        glRotatef(theta,0,1,0);
        
        glRotatef(180, 0.0, 1.0, 0.0); //line it up with 0 position
        glScalef(0.025, 0.025, 0.025);
        
        glScalef(20,60,20);
        glutWireSphere(2,10,10);
        
        glPopMatrix();
    }
    
    //middle ring of trees
    for (int theta=0; theta<360; theta+=10)
    {
        glPushMatrix();
        glTranslatef(5+60*sin(theta*PI/180), 0.0, 64+60*cos(theta*PI/180) );
        glRotatef(theta,0,1,0);
        
        glRotatef(180, 0.0, 1.0, 0.0); //line it up with 0 position
        glScalef(0.025, 0.025, 0.025);
        glScalef(20,750,20);
        glutSolidCube(1);
        
        glPopMatrix();
        glPushMatrix();
        glTranslatef(5+60*sin(theta*PI/180), 10.0, 64+60*cos(theta*PI/180) );
       
        glRotatef(theta,0,1,0);
        
        glRotatef(180, 0.0, 1.0, 0.0); //line it up with 0 position
        glScalef(0.025, 0.025, 0.025);
        
        glScalef(20,60,20);
        glutWireSphere(2,10,10);
        
        glPopMatrix();
    }
    
    //outer ring of trees
    for (int theta=0; theta<360; theta+=10)
    {
        glPushMatrix();
        glTranslatef(5+65*sin(theta*PI/180), 0.0, 64+65*cos(theta*PI/180) );
        glRotatef(theta,0,1,0);
        
        glRotatef(180, 0.0, 1.0, 0.0); //line it up with 0 position
        glScalef(0.025, 0.025, 0.025);
        glScalef(20,550,20);
        glutSolidCube(1);
        
        glPopMatrix();
        glPushMatrix();
        glTranslatef(5+65*sin(theta*PI/180), 7.0, 64+65*cos(theta*PI/180) );
        glRotatef(theta,0,1,0);
        
        glRotatef(180, 0.0, 1.0, 0.0); //line it up with 0 position
        glScalef(0.025, 0.025, 0.025);
        
        glScalef(20,60,20);
        glutWireSphere(2,10,10);
        
        glPopMatrix();
    }
}

void drawRoof(){
 // Begin drawing triangles
    //glColor4f(0.25,0.25,0.25,1);
    setMaterial(0.25,0.25,0.25);
    glBegin(GL_POLYGON);
    glVertex3f(-22,22,38);//left bottom
    glVertex3f(0,35,40);//top
    glVertex3f(22,22,38);//right bottom
    glEnd();
    glBegin(GL_POLYGON);
    glVertex3f(-22,22,90);
    glVertex3f(0,35,88);
    glVertex3f(22,22,90);
    glEnd();
    glBegin(GL_POLYGON);
    glVertex3f(-22,22,38);
    glVertex3f(0,35,40);
    glVertex3f(0,35,88);
    glVertex3f(-22,22,90);
    glEnd();
    glBegin(GL_POLYGON);
    glVertex3f(22,22,38);//right bottom
    glVertex3f(0,35,40);//top
    glVertex3f(0,35,88);//top
    glVertex3f(22,22,90);
    glEnd();
    
}

void drawOverHeadLamp(void){
    float lightAmb[] = { 0.1, 0.1, 0 };
    float lightDifAndSpec0[] = { 0.5, 0.5, 0.5, 1.0 };
    float lightPos0[] = { 0.0, 20.0, 64.0, 1.0 };
    float lightLookAt0[] = { 0.0, -1.0, 0.0};
    float lightCutoff0[] = {45.0};
    glLightModeli(GL_LIGHT_MODEL_LOCAL_VIEWER, 0); // Enable local viewpoint
   
    // Light0 properties.
       glLightfv(GL_LIGHT0, GL_AMBIENT, lightAmb);
       glLightfv(GL_LIGHT0, GL_DIFFUSE, lightDifAndSpec0);
       glLightfv(GL_LIGHT0, GL_SPECULAR, lightDifAndSpec0);
       glLightfv(GL_LIGHT0, GL_POSITION, lightPos0);
       glLightfv(GL_LIGHT0, GL_SPOT_DIRECTION, lightLookAt0);
       glLightfv(GL_LIGHT0, GL_SPOT_CUTOFF, lightCutoff0);

       
   // setMaterial(0,0,0);
    if (switchState) glEnable(GL_LIGHT0); else glDisable(GL_LIGHT0);
    makeSpotlightMaterial();
    glPushMatrix();
    glTranslatef(0.0,20.0,64);
    glutSolidSphere(2,10,10);
    glPopMatrix();
}

void drawTable(void){
    setMaterial(1,1,1);
    glPushMatrix();
    glTranslatef(-8,-0.7,70);
    glScaled(1,1,1);
    glutSolidCube(1);
    glPopMatrix();
    glPushMatrix();
    glTranslatef(-8,0.3,70);
    glScaled(5,1,5);
    glutSolidCube(1);
    glPopMatrix();
}

void drawFlashlight(void){
    setMaterial(0.25,0.25,0.5);
    glPushMatrix();
    if(flashlightState == 0){
        glTranslated(-8,1,70);
        glDisable(GL_LIGHT1);
    }
    else{
        glTranslated(meX+sin(angle*PI/180),meY-1,meZ +cos(angle*PI/180));
        glRotated(angle,0,1,0);
        glScaled(0.5,0.5,0.5);
    }
    glScaled(1,1,3);
    glutSolidCube(1);
    glPopMatrix();
    
    if(flashlightState == 1){
        makeSpotlightMaterial();
        float lightAmb[] = { 0.0, 0.0, 0.0, 1.0 };
        float lightDifAndSpec1[] = { 0.2, 0.2, 0.2, 1.0 };
        float lightPos1[] = { meX, meY-1, meZ, 1.0 };
        float lightLookAt1[] ={float(sin(angle*PI/180)), -1.0, float(cos(angle*PI/180))};
        float lightCutoff1[] = {45.0};
        // Light1 properties.
         glLightfv(GL_LIGHT1, GL_AMBIENT, lightAmb);
         glLightfv(GL_LIGHT1, GL_DIFFUSE, lightDifAndSpec1);
         glLightfv(GL_LIGHT1, GL_SPECULAR, lightDifAndSpec1);
         glLightfv(GL_LIGHT1, GL_POSITION, lightPos1);
         glLightfv(GL_LIGHT1, GL_SPOT_DIRECTION, lightLookAt1);
         glLightfv(GL_LIGHT1, GL_SPOT_CUTOFF, lightCutoff1);
         glEnable(GL_LIGHT1);

    }
}

void pinkSpotlight(void){
    if(pinkSpotlightState == 1){
        GLfloat pink[] = {1.0, 0.5, 0.5, 1.0}; // pink color values
        GLfloat lightPos[] = { 0,-1,64, 1.0 }; // spotlight position

        // calculate spotlight direction vector (pointing up in positive y direction)
        GLfloat spotlightDir[] = {0.0, 1.0, 0.0};

        // set spotlight properties
        glLightfv(GL_LIGHT4, GL_DIFFUSE, pink);
        glLightfv(GL_LIGHT4, GL_SPECULAR, pink);
        glLightfv(GL_LIGHT4, GL_POSITION, lightPos);
        glLightfv(GL_LIGHT4, GL_SPOT_DIRECTION, spotlightDir);
        glLightf(GL_LIGHT4, GL_SPOT_CUTOFF, 30.0f);
        glLightf(GL_LIGHT4, GL_SPOT_EXPONENT, 5.0f);

        // enable GL_LIGHT4
        glEnable(GL_LIGHT4);
        makeSpotlightMaterial();
        glPushMatrix();
        glTranslatef( 0,2,64 );
        if(selectOutCome ==1){
            glutSolidTeapot(1);
        }
        else{
            glutSolidCube(1);
        }
        glPopMatrix();
        
        

    }
    else{
        glDisable(GL_LIGHT4);
    }

}

//this code was taken grom chatgpt (prompt: how to draw a cylinder in opengl)
void drawCylinder(float radius, float height, int numSegments){
        // Calculate the angle between segments
        float angle = 2.0f * M_PI / numSegments;
        // Draw the top cap
        glBegin(GL_TRIANGLE_FAN);
        glVertex3f(0.0f, height, 0.0f);
        for (int i = 0; i <= numSegments; i++) {
            float x = radius * sin(i * angle);
            float z = radius * cos(i * angle);
            glVertex3f(x, height, z);
        }
        glEnd();
        // Draw the bottom cap
        glBegin(GL_TRIANGLE_FAN);
        glVertex3f(0.0f, 0.0f, 0.0f);
        for (int i = numSegments; i >= 0; i--) {
            float x = radius * sin(i * angle);
            float z = radius * cos(i * angle);
            glVertex3f(x, 0.0f, z);
        }
        glEnd();
        // Draw the sides
        glBegin(GL_TRIANGLE_STRIP);
        for (int i = 0; i <= numSegments; i++) {
            float x = radius * sin(i * angle);
            float z = radius * cos(i * angle);
            glVertex3f(x, 0.0f, z);
            glVertex3f(x, height, z);
        }
        glEnd();
}
//copied code ends here

void drawCauldron(void){
   
    setMaterial(0,0,0);
    glPushMatrix();
    glTranslatef(0,-1,64);
    drawCylinder(1.5, 1.5, 30);
    glPopMatrix();
    if(cauldronState == 1){
        float lightPos[] = { 0,-1,64, 1.0 };
        float lightAmb[] = { 0.0, 0.1, 0.0, 1.0 };
        float lightDif[] = { 0.0, 0.1, 0.0, 1.0 };
        float lightLookAt2[] = { 0.0, 1.0, 0.0};
        glLightfv(GL_LIGHT2, GL_POSITION, lightPos);
        glLightfv(GL_LIGHT2, GL_AMBIENT, lightAmb);
        glLightfv(GL_LIGHT2, GL_DIFFUSE, lightDif);
        glLightfv(GL_LIGHT2, GL_SPECULAR, lightDif);
        glLightfv(GL_LIGHT2, GL_SPOT_DIRECTION, lightLookAt2);
        float matEmissive[] = { 0.2, 0.2, 0.2, 1.0 };
        glMaterialfv(GL_FRONT, GL_EMISSION, matEmissive);
        glPushMatrix();
        glTranslatef(0,-1,64);
        drawCylinder(1, 1, 30);
        glPopMatrix();
        glEnable(GL_LIGHT2);
    }
    else{
        float matEmissive[] = { 0.0, 0.0, 0.0, 1.0 };
        glMaterialfv(GL_FRONT, GL_EMISSION, matEmissive);
        glDisable(GL_LIGHT2);
    }
    
}
void assignEndpointsMakeVector(
        float Px, float Py, float Pz,
        float Qx,float Qy, float Qz)
{
    startX=Px;
    startY=Py;
    startZ=Pz;
    endX=Qx;
    endY=Qy;
    endZ=Qz;
    Vx=endX-startX;
    Vy=endY-startY;
    Vz=endZ-startZ;
    
}

void increaseVector(void)
{
    if(tOrb== 10 && orbLeg== 0){
       
        cout << "in leg 0" << endl;
        assignEndpointsMakeVector(Px,Py,Pz,Qx,Qy,Qz);
        tOrb = 0;
        orbLeg = 1;
    }
    else if(tOrb == 10 && orbLeg == 1){
        cout << "in leg 1" << endl;
        Px = 0;
        Py = 0.5;
        Pz = 64;
        assignEndpointsMakeVector(Qx,Qy,Qz,Px,Py,Pz);
        tOrb = 0;
        orbLeg = 2;
    }
    else if(tOrb == 10 && orbLeg == 2){
        cout << "in leg 2" << endl;
        orbLeg = 3;
        initMagic = 0;
        pinkSpotlightState = 1;
    }
    tOrb++;
    Mx=tOrb/10.0*Vx ;
    My=tOrb/10.0*Vy ;
    Mz=tOrb/10.0*Vz ;
    redisplay();
    
}

void animateOrb(int someValue){
    if (initMagic == 1) increaseVector();
    glutTimerFunc(100, animateOrb, 1);
}



void drawOrb(void){
    float lightPos[] = { startX+Mx,startY+My,startZ+Mz, 1.0 };
    float lightAmb[] = { 0.2, 0.2, 0.2, 1.0 };
    float lightDifAndSpec[] = { 0.1, 0.1, 0.1, 1.0 };

    glLightfv(GL_LIGHT3, GL_POSITION, lightPos);
    glLightfv(GL_LIGHT3, GL_AMBIENT, lightAmb);
    glLightfv(GL_LIGHT3, GL_DIFFUSE, lightDifAndSpec);
    glLightfv(GL_LIGHT3, GL_SPECULAR, lightDifAndSpec);
    float matAmb[] = { 0.5f, 0.0f, 0.5f, 1.0f };
    float matDif[] = { 0.5f, 0.0f, 0.5f, 1.0f };
    float matSpec[] = { 1.0, 1.0, 1.0, 1.0 };
    float matShininess[] = { 100.0 };

    glMaterialfv(GL_FRONT, GL_AMBIENT, matAmb);
    glMaterialfv(GL_FRONT, GL_DIFFUSE, matDif);
    glMaterialfv(GL_FRONT, GL_SPECULAR, matSpec);
    glMaterialfv(GL_FRONT, GL_SHININESS, matShininess);
    glPushMatrix();
    glTranslated(Mx,My,Mz);
    glTranslated(startX,startY,startZ);
    glutSolidSphere(0.5, 50, 50);
    glPopMatrix();
    glEnable(GL_LIGHT3);
    
}

void drawSceneTask(void){
    glutSetWindow(tasks);
     glClear(GL_COLOR_BUFFER_BIT);
     glColor3f(0.0, 0.0, 0.0);
     //main title
     glRasterPos3f(22,85, 0.0);
     writeBitmapString((void*)font, "Welcome to the Haunted House");
     int xPosition = 10;
     int yPosition = 70;
     glRasterPos3f(xPosition,yPosition, 0.0);
     writeBitmapString((void*)font, "Complete these tasks:");
     glRasterPos3f(xPosition+=5,yPosition-=7, 0.0);//15,65
     writeBitmapString((void*)font, "-Use arrow keys to move around");
     glRasterPos3f(xPosition,yPosition-=7, 0.0);
     writeBitmapString((void*)font, "-Click on objects to animate them");
     glRasterPos3f(xPosition,yPosition-=7, 0.0);
     writeBitmapString((void*)font, "-Go near the table to pick up a flashlight");
     glRasterPos3f(xPosition,yPosition-=7, 0.0);
     writeBitmapString((void*)font, "-Go near cauldron to see it glow");
    glRasterPos3f(xPosition,yPosition-=7, 0.0);
    writeBitmapString((void*)font, "-right click > animate orb to see magic!");
    glFlush();
    glutSwapBuffers();
     
}

// Drawing routine.
void drawScene(void)
{
    glutSetWindow(house);
    // Light property vectors.
    float globAmb[] = { m, m, m, 1.0 };
    glLightModelfv(GL_LIGHT_MODEL_AMBIENT, globAmb); // Global ambient light.
       
    
    glClear (GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    glLoadIdentity();

    //gluLookAt goes here
    gluLookAt(meX,meY,meZ,meX+sin(angle*PI/180),meY,meZ + cos(angle*PI/180),0,1,0);
    /// SOOOO IMPORTANT
    /// reminder: glu likes radians, gl likes degrees!!!!!
    
    
   glShadeModel(GL_SMOOTH); // Restore smooth shading.
    if(isPicking){
        //draw fake colors
        //setMaterial(1,0,0);
        glDisable(GL_LIGHTING);
        glColor3f(1,0,0);//red
        drawDoor();
        
        glColor3f(0,1,0);//set to green
        drawLightSwitch();
        
        glColor3f(0,0,1); // set to blue
        drawShades();
        
        getID(xClick,yClick);
        isPicking = false;
        glEnable(GL_LIGHTING);
    }
    else{
        //draw real images
        drawSpookyGrass();
        drawTrees();
       // glColor4f(0.51,0.0,0.51,1);
        setMaterial(0.51,0.0,0.51);
        drawDoor();
        drawHouseFrame();
        drawRoof();
        
        //code similar to ballAndTorusShadowedNoLighting.cp
        glPushMatrix();
        glTranslatef(0,-2,0);
        glScalef(1.0,0.0,1.0);
        drawTrees();
        glPopMatrix();
        
       // glColor4f(1,1,1,1);
        setMaterial(1,1,1);
        drawLightSwitch();
        
        //lightSwitchShadow
        glPushMatrix();
        glColor4f(0,0,0,1);
        glTranslatef(0,-2,0);
        glScalef(1.0,0.0,1.0);
        drawLightSwitch();
        glPopMatrix();
        
        drawOverHeadLamp();
        
        setMaterial(0.5,0,0);
        drawShades();
        drawTable();
        drawFlashlight();
        drawCauldron();
        drawOrb();
        pinkSpotlight();
        glFlush();
        
        
        glutSwapBuffers();
    }
}

void specialKeyInput(int key, int x, int y)
{
    switch(key){
        case GLUT_KEY_UP: //forward
            meZ+=stepsize*cos(angle * (PI/180));
            meX+=stepsize*sin(angle* (PI/180)) ;
            break;
        case GLUT_KEY_DOWN: //back
            meZ-=stepsize*cos(angle * (PI/180));
            meX-=stepsize*sin(angle* (PI/180));
            break;
        case GLUT_KEY_RIGHT: //turn right
            angle-=turnsize;
            break;
        case GLUT_KEY_LEFT: //turn left
            angle+=turnsize;
            break;
    }//end switch
    
    if(meX < -3 && meX > -14 && meZ > 64 && meZ < 75){
        flashlightState = 1;
    }
    if(meX < 5 && meX > -5 && meZ > 59 && meZ < 69){
        cauldronState = 1;
    }
    else{
        cauldronState = 0;
    }
    redisplay();
}

// Routine to output interaction instructions to the C++ window.
void printInteraction(void)
{
    cout << "Interaction:" << endl;
    cout << "\tup arrow - step forward" << endl;
    cout << "\tdown arrow - step backward" << endl;
    cout << "\tright arrow - turn to the right" << endl;
    cout << "\tleft arrow - turn to the left" << endl;
    cout << "\tr - reset to standing in the center ";
    cout << "facing 0 degrees." << endl;
    cout << "\td - opens/closes the door" << endl;
    cout << "\tl - turns on/off the ceiling lamp"<< endl;
    cout << "\ts - opens/closes the window shade" << endl;
    cout << "\tf - turns off the flashlight" << endl;
    cout << "\tall object above are clickable!" << endl;
    }

// Keyboard input processing routine.
void keyInput(unsigned char key, int x, int y)
{
    switch(key)
    {
        case 27:
            exit(0);
            break;
        case 'r':
            meX = 0;
            meY = 0;
            meZ = 0;
            angle = 0;
            redisplay();
            break;
        case 'd':
            cout << "toggle door to haunted house!" << endl;
            animateDoor=!animateDoor;
            redisplay();
            break;
        case 'l':
            cout << "toggle haunted house lights" << endl;
            if(switchState == 0){
                switchState = 1;
            }
            else{
                switchState = 0;
            }
            redisplay();
            break;
        case 's':
            cout << "toggle shades" << endl;
            animateShades=!animateShades;
            redisplay();
            break;
        
        case 'f':
            cout << "flashlight off" << endl;
            flashlightState = 0;
            redisplay();
            break;
        default:
            break;
    }
}

void outcomesMenu(int id){
    switch(id){
        case 1:
            selectOutCome = 1;
            break;
        case 2:
            selectOutCome = 2;
            break;
    }
    redisplay();
}

void generalMenu(int id){
    if(id==1) {
        initMagic=!initMagic;
        Px=-3;
        Py=-1;
        Pz=64;
        orbLeg = 0;
        tOrb = 0;
        pinkSpotlightState = 0;
    }
    redisplay();
    
}

void generateMenu(){
    
 
    
    int outcomeSubMenu;
    outcomeSubMenu = glutCreateMenu(outcomesMenu);
    glutAddMenuEntry("outcome 1", 1);
    glutAddMenuEntry("outcome 2",2);
    
    glutCreateMenu(generalMenu);
    glutAddSubMenu("Outcomes", outcomeSubMenu);
    glutAddMenuEntry("animate orb",1);
    
    glutAttachMenu(GLUT_RIGHT_BUTTON);
}


// Main routine.
int main(int argc, char **argv)
{
    
    printInteraction();
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);
    // Second top-level window definition.
     //Setting up the window with the circle
    glutInitWindowSize(500, 500);
    glutInitWindowPosition(600, 100);
    tasks = glutCreateWindow("tasks");
    setupTask();
    glutDisplayFunc(drawSceneTask);
    glutReshapeFunc(resizeTask);
    
    //first window
    glutInitWindowSize(500, 500);
    glutInitWindowPosition(100, 100);
    house = glutCreateWindow("spooky haunted house tour");
    setup();
    glutDisplayFunc(drawScene);
    glutReshapeFunc(resize);
    glutKeyboardFunc(keyInput);
    glutSpecialFunc(specialKeyInput);
    glutMouseFunc(pickFunction); // Mouse control.
    glutTimerFunc(5,rollUpShades,1);
    glutTimerFunc(5,rollDownShades,1);
    glutTimerFunc(5,openDoor,1);
    glutTimerFunc(5,closeDoor,1);
    glutTimerFunc(5,animateOrb,1);
    generateMenu();
    glutMainLoop();
    return 0;
}
