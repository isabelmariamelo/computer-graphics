//
//  encore.cpp
/*
 This is a computer graphics program that will teach you how to become a ballerina!
 */

//  Intro to Computer Graphics: final project
//
//  Created by Isabel Melo on 4/19/23.

//

#define _CRT_SECURE_NO_DEPRECATE

#include <cstdlib>
#include <fstream>
#include <iostream>
#include <stdio.h>
#include <cmath>

#ifdef __APPLE__
#  include <GLUT/glut.h>
#else
#  include <GL/glut.h>
#endif

#define PI 3.14159
using namespace std;

//loading texture parameters
GLuint myCurtain;
int wrap = 0;
static unsigned int texture[2]; // Array of texture indices.

static int stage, selection; // Window identifiers.
static float meX=0, meY=0,meZ=0; // where eye of camera is standind
static float angle=0;  //angle facing
static float stepsize=1.0;  //step size
static float turnsize=5.0; //degrees to turn
bool isPicking = false;

static float endX, endY, endZ; //ending point for this leg of trip
static float Vx, Vy, Vz;
static float Mx=0,My=0,Mz=0; //partial vector in direction of V
static float Px=-3 , Py=-1, Pz=64;
static float Qx=0 , Qy=10, Qz=64;
static float startX= Px, startY=Py, startZ=Pz;//starting point for this leg of trip
//coordinates of point clicked
int xClick=0;
int yClick=0;
int height =0;

//used to fill radio buttons and select dance moves
int first = 0;
int second = 0;
int third = 0;
int forth = 0;
int fifth = 0;


//ballerina coordinates for position control relative to the center of the head
float balX = 0;
float balY = 15;
float balZ = 30;

//arm joints
float rightShoulderX = 0;
float rightShoulderZ = 0;
float leftShoulderX = 0;
float leftShoulderZ = 0;
float rightElbowX = 0;
float rightElbowZ = 0;
float leftElbowX = 0;
float leftElbowZ = 0;

//leg joints
float rightHipX = 0;
float rightHipZ = 0;
float leftHipX = 0;
float leftHipZ = 0;
float rightKneeX = 0;
float rightKneeZ = 0;
float leftKneeX = 0;
float leftKneeZ = 0;

int jointId = 0;
float turnAngle = 0;
bool startTurn = false;
bool startPique = false;
bool startChat = false;
bool startSaute = false;

bool sauteAway = false;

float dressColor[] = {0.78, 0.68, 0.84};

bool lightOn = true;

bool moveX = true;
bool moveZ = true;

/*
 [0] = left shoulder
 [1] = right shoulder
 [2] = left elbow
 [3] = right elbow
 [4] = left hip
 [5] = right hip
 [6] = left knee
 [7] = right knee
 */

static long font = (long)GLUT_BITMAP_HELVETICA_18;
static long fontSub = (long)GLUT_BITMAP_HELVETICA_12;
bool danceRandom = false;

//control points for curtain made with a Bezier Surface
static float controlPoints[6][4][3]=
{
    {{-3,-0.5,5,}, {-0.25,0.8,5,}, {0.25,1.3,5,}, {3.3,0.4,5,}},
    {{-3,0,3,}, {-0.25,0,3,}, {0.25,0,3,}, {3,0,3,}},
    {{-3,0,1,}, {-0.25,0,1,}, {0.25,0,1,}, {3,0,1,}},
    {{-3.5,0,-1,}, {-5.75,-0.1,-1,}, {-5.25,0,-1,}, {-7.2,0,-1,}},
    {{-3,0.6,-3,}, {-0.25,-1.5,-3,}, {0.25,-2.2,-3,}, {3.4,-2.9,-3,}},
    {{-3,0.5,-5,}, {-0.85,-0.4,-5,}, {0.85,-1.1,-5,}, {3,0.5,-5}}
};

//code below modified from loadTexture.cpp

void colisionDetection(void){
    
    //set movement parameters
    if(meX > -55 && meX < 55 && meZ > 0 && meZ < 36){
        cout << "ok to move" << endl;
        moveX = true;
        moveZ = true;
        //detect curtains
        if(meX > 10.5 && meX < 33 && meZ > 9.5 && meZ < 16){
            cout << "bumping into the stage left curtain" << endl;
            if(meX-5 < 10.5 ){
                meX = 10.5;
            }
            else{
                meX = 33;
            }
            if(meZ-5 < 9.5){
                meZ = 9.5;
            }
            else{
                meZ = 16;
            }
        }
        if(meX > -30 && meX < -11 && meZ > 11 && meZ < 20){
            cout << "bumping into stage right curtain" << endl;
            if(meX-5 < -30 ){
                meX = -30;
            }
            else{
                meX = -11;
            }
            if(meZ-5 < 11){
                meZ = 11;
            }
            else{
                meZ = 20;
            }
        }
    }
    else{
        if(meX < -55){
            meX = -55;
        }
        else if(meX > 55){
            meX = 55;
        }
        if(meZ > 36){
            meZ = 36;
        }
        else if(meZ < 0){
            meZ = 0;
        }
    }
}


// Struct of bitmap file.
struct BitMapFile
{
  int sizeX;
  int sizeY;
  unsigned char *data;
};

// Routine to read a bitmap file.
// Works only for uncompressed bmp files of 24-bit color.
BitMapFile *getBMPData(string filename)
{
    BitMapFile *bmp = new BitMapFile;
    unsigned int size, offset, headerSize;
    
    // Read input file name.
    ifstream infile(filename.c_str(), ios::binary);
    
    // Get the starting point of the image data.
    infile.seekg(10);
    infile.read((char *) &offset, 4);
    
    // Get the header size of the bitmap.
    infile.read((char *) &headerSize,4);
    
    // Get width and height values in the bitmap header.
    infile.seekg(18);
    infile.read( (char *) &bmp->sizeX, 4);
    infile.read( (char *) &bmp->sizeY, 4);
    
    // Allocate buffer for the image.
    size = bmp->sizeX * bmp->sizeY * 24;

    bmp->data = new unsigned char[size];
    
    // Read bitmap data.
    infile.seekg(offset);
    infile.read((char *) bmp->data , size);
    
    // Reverse color from bgr to rgb.
    int temp;
    for (int i = 0; i < size; i += 3)
    {
        temp = bmp->data[i];
        bmp->data[i] = bmp->data[i+2];
        bmp->data[i+2] = temp;
    }
    
    return bmp;
}

void loadExternalTextures()
{
   // Local storage for bmp image data.
   BitMapFile *image[1];
   
   // Load the texture.
   image[0] = getBMPData("/Users/isabelmelo/Desktop/CIS425/Code/graphics2/graphics2/immeloTEXTURES/curtains.bmp");

   // Activate texture index texture[0].
   glBindTexture(GL_TEXTURE_2D, texture[0]);

   // Set texture parameters for wrapping.
   glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
   glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);

   // Set texture parameters for filtering.
   glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
   glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);

   // Specify an image as the texture to be bound with the currently active texture index.
   glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, image[0]->sizeX, image[0]->sizeY, 0,
                GL_RGB, GL_UNSIGNED_BYTE, image[0]->data);
}



void redisplay(void){
    glutSetWindow( stage );
    glutPostRedisplay();  // Update screen with new rotation data
    glutSetWindow( selection );
    glutPostRedisplay();
}


void writeBitmapString(void *font, const char *string)
{
   const char *c;

   for (c = string; *c != '\0'; c++) glutBitmapCharacter(font, *c);
}


// Initialization routine.
void setupStage(void)
{
    
    glEnable(GL_NORMALIZE);
    glEnable(GL_DEPTH_TEST); // Enable depth testing.
    
    glEnable(GL_LIGHTING);
    glEnable(GL_LIGHT0);
    glShadeModel(GL_FLAT);
    float ambient[] = { 0.1f, 0.1f, 0.1f, 1.0f };
    glLightfv(GL_LIGHT0, GL_AMBIENT, ambient);
    glClearColor(0,0,0,1); // black background
    glGenTextures(2, texture);
    loadExternalTextures();
    glEnable(GL_TEXTURE_2D);
    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
    glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_REPLACE);

}

void setupSelection(void){
    glClearColor(1.0, 1.0, 1.0, 0.0);
}

void resizeSelection(int w, int h){
    glViewport(0, 0, (GLsizei) w, (GLsizei) h);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();

    // Aspect ratio matches the window.
    glOrtho(0.0, 100.0, 0.0, 100.0, -1.0, 1.0);

    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
}
// OpenGL window reshape routine.
void resizeStage(int w, int h)
{
    glViewport(0, 0, (GLsizei)w, (GLsizei)h);
    height = h;
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluPerspective(120,1,1,100);
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
}

// Routine to draw a stroke character string.
void writeStrokeString(void *font, const char *string)
{
    const char *c;
    for (c = string; *c != '\0'; c++) glutStrokeCharacter(font, *c);
}

void getID(int x, int y)
{
    unsigned char pixel[3];
    glReadPixels(x, y, 1, 1, GL_RGB, GL_UNSIGNED_BYTE, pixel);
    cout << "R: " << (int)pixel[0] << endl;
    cout << "G: " << (int)pixel[1] << endl;
    cout << "B: " << (int)pixel[2] << endl;
    cout << endl;
    if(pixel[0]==255 && pixel[1]==0 && pixel[2]==0){
        cout << "time to dance " << danceRandom << endl;
            danceRandom =! danceRandom;
        }
    }


void choreography(void){
    if(danceRandom==true && isPicking == false){
        cout << "choreo time" << endl;
        if(startChat == false && startTurn == false && startPique == false && startSaute == false){
            srand(time(0));
            int seed = rand() % 5 + 1;
            switch(seed){
                case 1:
                    startTurn = true;
                    break;
                case 2:
                    startChat = true;
                    break;
                case 3:
                    sauteAway = false;
                    startSaute = true;
                    break;
                case 4:
                    startPique = true;
                    break;
                case 5:
                    sauteAway = false;
                    startSaute = true;
                    break;
            }
        }
    }
}

void setMaterial(float r, float g, float b){
    // Material property vectors.
    float matAmb[] = {r,g,b,1};
    float difr;
    float difg;
    float difb;
    if(r==0){
        difr = 0.0f;
    }
    else{
        difr = 1.0f-r;
    }
    if(g==0){
        difg = 0.0f;
    }
    else{
        difg = 1.0f-g;
    }
    if(b==0){
        difb = 0.0f;
    }
    else{
        difb = 1.0f-b;
    }
    
    float matDif[] = {difr,difg,difb, 1};
    float matSpec[] = { 0.8, 0.8, 0.8, 0.8 };
    float matShine[] = { 50.0 };
    glMaterialfv(GL_FRONT, GL_DIFFUSE, matDif);
    glMaterialfv(GL_FRONT, GL_AMBIENT, matAmb);
    glMaterialfv(GL_FRONT, GL_SPECULAR, matSpec);
    glMaterialfv(GL_FRONT, GL_SHININESS, matShine);
}
void drawRadioButtons(float x, float y, float z){
    float angle;
    int i;
    glColor3f(0,0,0);
    
    if(z==1){
        glBegin(GL_POLYGON);
    }
    else{
        //glBegin(GL_FILL);
        glBegin(GL_LINE_LOOP);
    }
    for(i = 0; i < 30; ++i)
    {
       angle = 2 * PI * i / 30;
       glVertex2f(x + cos(angle) , y + sin(angle));
    }
    
    glEnd();
    
}
void drawFonts(void){
    glColor3f(0,0,0);
    glRasterPos3f(40,85, 0.0);
    writeBitmapString((void*)font, "let's dance!");
    glColor3f(0,0,0);
    glRasterPos3f(23,75, 0.0);
    writeBitmapString((void*)fontSub, "first position (1)");
    glRasterPos3f(23,65, 0.0);
    writeBitmapString((void*)fontSub, "second position (2)");
    glRasterPos3f(23,55, 0.0);
    writeBitmapString((void*)fontSub, "third position (3)");
    glRasterPos3f(23,45, 0.0);
    writeBitmapString((void*)fontSub, "fourth position (4)");
    glRasterPos3f(23,35, 0.0);
    writeBitmapString((void*)fontSub, "fifth position (5)");
    drawRadioButtons(20,76,first);
    drawRadioButtons(20,66,second);
    drawRadioButtons(20,56,third);
    drawRadioButtons(20,46,forth);
    drawRadioButtons(20,36,fifth);
    glRasterPos3f(53,75, 0.0);
    writeBitmapString((void*)fontSub, "pirouette (t)");
    drawRadioButtons(50,76,startTurn);
    glRasterPos3f(53,65, 0.0);
    writeBitmapString((void*)fontSub, "pas de chat (c)");
    drawRadioButtons(50,66,startChat);
    glRasterPos3f(53,55, 0.0);
    writeBitmapString((void*)fontSub, "saute de chat (j)");
    drawRadioButtons(50,56,startSaute);
    glRasterPos3f(53,45, 0.0);
    writeBitmapString((void*)fontSub, "pique turn (T)");
    drawRadioButtons(50,46,startPique);
    if(jointId != 8){
        glRasterPos3f(22,25, 0.0);
        writeBitmapString((void*)font, "press 'm' to move yourself...");
    }
    else if(jointId == 8){
        glRasterPos3f(22,25, 0.0);
        writeBitmapString((void*)font, "use arrow keys to move!");
    }
}


//glOrtho(0.0, 100.0, 0.0, 100.0, -1.0, 1.0);
void drawSceneSelection(void){
    glutSetWindow(selection);
    glClear(GL_COLOR_BUFFER_BIT);
    drawFonts();
    glFlush();
    glutSwapBuffers();
}


void makeCurtainLights(float x, float y, float z){

    GLfloat light_position[] = { x+10, y, z, 0.0 };
    glLightfv(GL_LIGHT1, GL_POSITION, light_position);
    GLfloat light_ambient[] = { 0.2f, 0.0f, 0.0f, 1.0f };
    GLfloat light_diffuse[] = { 0.8f, 0.0f, 0.0f, 1.0f };
    GLfloat light_specular[] = { 0.8f, 0.8f, 0.8f, 1.0f };
    float lightLookAt1[] ={y, -1.0, z};
    float lightCutoff1[] = {45.0};

    glLightfv(GL_LIGHT1, GL_POSITION, light_position);
    glLightfv(GL_LIGHT1, GL_AMBIENT, light_ambient);
    glLightfv(GL_LIGHT1, GL_DIFFUSE, light_diffuse);
    glLightfv(GL_LIGHT1, GL_SPECULAR, light_specular);
    glLightfv(GL_LIGHT1, GL_SPOT_DIRECTION, lightLookAt1);
    glLightfv(GL_LIGHT1, GL_SPOT_CUTOFF, lightCutoff1);

    // Enable lighting and depth testing
    glEnable(GL_LIGHTING);
    glEnable(GL_LIGHT1);
    glDepthFunc(GL_LEQUAL);
    glEnable(GL_DEPTH_TEST);
}



void drawCurtainBackdrop(void){
    // Activate a texture.
    glEnable(GL_TEXTURE_2D);
     glBindTexture(GL_TEXTURE_2D, texture[0]);
    // Set up texture parameters (e.g., filtering, wrapping modes)
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

    // Draw textured object with darker color
    glColor4f(0.0f, 0.0f, 0.0f, 0.5f);  // Set darker color (50% opacity)

    // Map the texture onto a square polygon.
    glBegin(GL_POLYGON);
       glTexCoord2f(0.0, 0.0); glVertex3f(-60, -20, 40.0);
       glTexCoord2f(1.0, 0.0); glVertex3f(60.0, -20, 40.0);
       glTexCoord2f(1.0, 1.0); glVertex3f(60.0, 70.0, 40.0);
       glTexCoord2f(0.0, 1.0); glVertex3f(-60.0, 70.0, 40.0);
    glEnd();
    glColor4f(1.0f, 1.0f, 1.0f, 1.0f);
    
    glDisable(GL_TEXTURE_2D);
}

void drawCurtain(void){
    setMaterial(0.8, 0.0, 0.0);
    glPushMatrix();
    glTranslatef(22,13,15);
    glRotatef(-90, 1.0, 0.0, 0.0);
    glRotatef(180,0,1,0);
    glScalef(3.2,3.2,3.2);
    //from BezierSurface.cpp modified
    // Specify and enable the Bezier surface.
    glMap2f(GL_MAP2_VERTEX_3, 0, 1, 3, 4, 0, 1, 12, 6, controlPoints[0][0]);
    glEnable(GL_MAP2_VERTEX_3);

    // Draw the Bezier surface using a mesh approximation.
  
    glMapGrid2f(20, 0.0, 1.0, 20, 0.0, 1.0);
    glEvalMesh2(GL_FILL, 0, 20, 0, 20);
    glPopMatrix();
    
    glPushMatrix();
    glTranslatef(-20,13,15);
    glRotatef(90, 1.0, 0.0, 0.0);
    glRotatef(180,0,1,0);
    glRotatef(180,0,0,1);
    glScalef(3.2,3.2,3.2);
    // Specify and enable the Bezier surface.
    glMap2f(GL_MAP2_VERTEX_3, 0, 1, 3, 4, 0, 1, 12, 6, controlPoints[0][0]);
    glEnable(GL_MAP2_VERTEX_3);

    // Draw the Bezier surface using a mesh approximation.

    glMapGrid2f(20, 0.0, 1.0, 20, 0.0, 1.0);
    glEvalMesh2(GL_FILL, 0, 20, 0, 20);
    glPopMatrix();
    
}

void makeSpotlightMaterial(){
    // Material property vectors.
    float matAmbAndDif[] = {1,0.9,0,1};
    float matSpec[] = { 1.0, 1.0, 1,0, 1.0 };
    float matShine[] = { 50.0 };

    // Material properties of sphere.
    glMaterialfv(GL_FRONT, GL_AMBIENT_AND_DIFFUSE, matAmbAndDif);
    glMaterialfv(GL_FRONT, GL_SPECULAR, matSpec);
    glMaterialfv(GL_FRONT, GL_SHININESS, matShine);
}

void drawOverHeadLamp(void){
    float lightAmb[] = { 0.1, 0.1, 0 };
    float lightDifAndSpec0[] = { 0.5, 0.5, 0.5, 1.0 };
    float lightPos0[] = { 0.0, 50.0, 30.0, 1.0 };
    float lightLookAt0[] = { 0.0, -1.0, 0.0};
    float lightCutoff0[] = {25.0};
    glLightModeli(GL_LIGHT_MODEL_LOCAL_VIEWER, 0); // Enable local viewpoint
   
    // Light3 properties.
       glLightfv(GL_LIGHT3, GL_AMBIENT, lightAmb);
       glLightfv(GL_LIGHT3, GL_DIFFUSE, lightDifAndSpec0);
       glLightfv(GL_LIGHT3, GL_SPECULAR, lightDifAndSpec0);
       glLightfv(GL_LIGHT3, GL_POSITION, lightPos0);
       glLightfv(GL_LIGHT3, GL_SPOT_DIRECTION, lightLookAt0);
       glLightfv(GL_LIGHT3, GL_SPOT_CUTOFF, lightCutoff0);

       
   // setMaterial(0,0,0);
    if(lightOn){
        glEnable(GL_LIGHT3);
    }
    else{
        glDisable(GL_LIGHT3);
    }
    makeSpotlightMaterial();
    glPushMatrix();
    glTranslatef(0.0,50.0,30.0);
    glutSolidSphere(2,10,10);
    glPopMatrix();
}


void drawStage(void){
    setMaterial(0.5,0.5,0.5);
    glPushMatrix();
    glTranslatef(0,-7,30);
    glScalef(80,7,20);
    glutSolidCube(1);
    glPopMatrix();
    drawOverHeadLamp();

}
float hairColor[] = {0.35f, 0.18f, 0.11f};
float skinColor[] = {0.8f, 0.5f, 0.3f};

void makeSkinMaterial(void){
    //make skin material
    GLfloat ambient[] = {skinColor[0], skinColor[1], skinColor[2], 1.0f};
    GLfloat specular[] = {0.2f, 0.2f, 0.2f, 1.0f};
    GLfloat shininess = 50.0f;

    glMaterialfv(GL_FRONT, GL_AMBIENT_AND_DIFFUSE, ambient);
    glMaterialfv(GL_FRONT, GL_SPECULAR, specular);
    glMaterialf(GL_FRONT, GL_SHININESS, shininess);
}

void drawBallerinaHead(void){
    
    //fix this if time
    //eyes
    GLfloat ambient3[] = {0.0f, 0.0f, 0.0f, 1.0f};
    GLfloat specular3[] = {0.2f, 0.2f, 0.2f, 1.0f};
    GLfloat shininess3 = 0.0f;
    glMaterialfv(GL_FRONT, GL_AMBIENT_AND_DIFFUSE, ambient3);
    glMaterialfv(GL_FRONT, GL_SPECULAR, specular3);
    glMaterialf(GL_FRONT, GL_SHININESS, shininess3);
    glPushMatrix();
    glTranslatef(balX+0.7,balY+2,balZ-2); // move the bun up
    glutSolidSphere(0.4, 30, 30);
    glPopMatrix();
    glPushMatrix();
    glTranslatef(balX-0.7,balY+2,balZ-2); // move the bun up
    glutSolidSphere(0.4, 30, 30);
    glPopMatrix();
    
    //lips
    GLfloat ambient1[] = {0.8f, 0.4f, 0.5f, 1.0f};
    GLfloat specular1[] = {0.2f, 0.2f, 0.2f, 1.0f};
    GLfloat shininess1 = 40.0f;

    glMaterialfv(GL_FRONT, GL_AMBIENT_AND_DIFFUSE, ambient1);
    glMaterialfv(GL_FRONT, GL_SPECULAR, specular1);
    glMaterialf(GL_FRONT, GL_SHININESS, shininess1);
    
    glPushMatrix();//top lip
    if(balX == 0){
        glScalef(3,1,1);
    }
    glTranslatef(balX,balY+0.6,balZ-2);
    glutSolidSphere(0.2, 30, 30);
    glPopMatrix();
    
    glPushMatrix();//bottom lip
    if(balX == 0){
        glScalef(3,1,1);
    }
    glTranslatef(balX,balY+0.4,balZ-2);
    glutSolidSphere(0.2, 30, 30);
    glPopMatrix();
    
    //bun
    
    GLfloat ambient2[] = {hairColor[0],hairColor[1],hairColor[2], 1.0f};
    GLfloat specular2[] = {0.2f, 0.2f, 0.2f, 1.0f};
    GLfloat shininess2 = 0.0f;
    glMaterialfv(GL_FRONT, GL_AMBIENT_AND_DIFFUSE, ambient2);
    glMaterialfv(GL_FRONT, GL_SPECULAR, specular2);
    glMaterialf(GL_FRONT, GL_SHININESS, shininess2);
    glPushMatrix();
    glTranslatef(balX,balY+7,balZ); // move the bun up
    glScalef(1,1,1);
    glutSolidSphere(1.5, 30, 30);
    glPopMatrix();
    
    //hair
    // Define the plane equation for the clipping plane
    glPushMatrix();
    glTranslatef(balX,balY+3,balZ);
    glRotated(90,0,0,1);
    glScalef(1.5,1,1);
    GLdouble planeEq[] = {1.0, 0.0, 0.0, 0.0};
    glClipPlane(GL_CLIP_PLANE0, planeEq);
    glEnable(GL_CLIP_PLANE0);
    glutSolidSphere(2.7, 100, 100);
    glDisable(GL_CLIP_PLANE0);
    
    glPopMatrix();
    
    makeSkinMaterial();
    
    //head
    glPushMatrix();
    glScalef(1,1.2,1);
    glTranslatef(balX,balY,balZ);
    glutSolidSphere(2.5, 100, 100);
    glPopMatrix();
    
    //neck
    glPushMatrix();
    GLUquadricObj* quad = gluNewQuadric();
    glTranslatef(balX,balY-0.2,balZ);
    glRotatef(90,1,0,0);
    gluCylinder(quad, 0.7, 0.7, 1.0, 32, 32);
    gluDeleteQuadric(quad);
    glPopMatrix();
    
    glPushMatrix();
    //glScalef(0.8,1.2,1);
    glTranslatef(balX,balY-1.5,balZ);
    glRotatef(90,1,0,0);
    glutSolidCone(2.4,6, 100, 100);
    glPopMatrix();
}

void drawBallerinaDress(void){
    //leotard
    if(isPicking){
        cout << "ballerina in red" << endl;
        glPushMatrix();
        glTranslatef(balX,balY-2.5,balZ);
        glRotatef(90,1,0,0);
        glutSolidCone(3.1,5.4, 100, 100);
        glPopMatrix();
        
        glPushMatrix();
        glScalef(1,1.2,1);
        glTranslatef(balX,balY-10.5,balZ);
        glRotatef(-90,1,0,0);
        glutSolidCone(5.5,4.5, 100, 100);
        glPopMatrix();
    }
    else{
        setMaterial(dressColor[0], dressColor[1], dressColor[2]);
        
        glPushMatrix();
        glTranslatef(balX,balY-2.5,balZ);
        glRotatef(90,1,0,0);
        glutSolidCone(3.1,5.4, 100, 100);
        glPopMatrix();
        
        glPushMatrix();
        glScalef(1,1.2,1);
        glTranslatef(balX,balY-10.5,balZ);
        glRotatef(-90,1,0,0);
        glutSolidCone(5.5,4.5, 100, 100);
        glPopMatrix();
        //glutSwapBuffers();
    }
}

//this needs to only rotate based on the hip aka the top of the thigh
void drawBallerinaRightThigh(void){
    makeSkinMaterial();
    
    glPushMatrix();
    glTranslatef(balX+1.2,balY-8.6,balZ);
    glRotatef(rightHipX,1,0,0);
    glRotatef(rightHipZ,0,0,1);
    glTranslatef(0,-1.5,0);
    glScalef(1,3,1);
    glutSolidSphere(1, 100, 100);
    glPopMatrix();
    
}

void drawBallerinaLeftThigh(void){
    makeSkinMaterial();
    
    glPushMatrix();
    glTranslatef(balX-1.2,balY-8.6,balZ);
    glRotatef(leftHipX,1,0,0);
    glRotatef(leftHipZ,0,0,1);
    glTranslatef(0,-1.5,0);
    glScalef(1,3,1);
    glutSolidSphere(1, 100, 100);
    glPopMatrix();
    
}

void drawBallerinaLeftCalf(void){
    makeSkinMaterial();
    glPushMatrix();
        glTranslatef(balX-1.2,balY-8.6,balZ);
        glRotatef(leftHipX,1,0,0);
        glRotatef(leftHipZ,0,0,1);
        glTranslatef(0,-6,0);
        glPushMatrix(); // Save the current matrix
        glTranslatef(0,1.125,0); // Translate the forearm back to the elbow joint
        glRotatef(leftKneeX,1,0,0); // Rotate around the elbow joint
        glRotatef(leftKneeZ,0,0,1);
        glTranslatef(0,-1.125,0); // Translate the forearm back to its original position
        glScalef(1,3,1);
        glutSolidSphere(0.75, 100, 100);
        glPopMatrix(); // Restore the previous matrix
    glPopMatrix();
}

void drawBallerinaRightCalf(void){
    makeSkinMaterial();
    glPushMatrix();
        glTranslatef(balX+1.2,balY-8.6,balZ);
        glRotatef(rightHipX,1,0,0);
        glRotatef(rightHipZ,0,0,1);
        glTranslatef(0,-6,0);
        glPushMatrix(); // Save the current matrix
        glTranslatef(0,1.125,0); // Translate the forearm back to the elbow joint
        glRotatef(rightKneeX,1,0,0); // Rotate around the elbow joint
        glRotatef(rightKneeZ,0,0,1);
        glTranslatef(0,-1.125,0); // Translate the forearm back to its original position
        glScalef(1,3,1);
        glutSolidSphere(0.75, 100, 100);
        glPopMatrix(); // Restore the previous matrix
    glPopMatrix();
}

void drawBallerinaLeftShoe(void){
    //make shoe material
    GLfloat ambient[] = {0.88f, 0.54f, 0.65f, 1.0f};
    GLfloat specular[] = {0.2f, 0.2f, 0.2f, 1.0f};
    GLfloat shininess = 50.0f;

    glMaterialfv(GL_FRONT, GL_AMBIENT_AND_DIFFUSE, ambient);
    glMaterialfv(GL_FRONT, GL_SPECULAR, specular);
    glMaterialf(GL_FRONT, GL_SHININESS, shininess);
    glPushMatrix();
        glTranslatef(balX-1.2,balY-8.6,balZ);
        glRotatef(leftHipX,1,0,0);
        glRotatef(leftHipZ,0,0,1);
        glTranslatef(0,-6,0);
        glPushMatrix(); // Save the current matrix
        glTranslatef(0,1.125,0); // Translate the forearm back to the elbow joint
        glRotatef(leftKneeX,1,0,0); // Rotate around the elbow joint
    glRotatef(leftKneeZ,0,0,1);
        glTranslatef(0,-1.125,0); // Translate the forearm back to its original position
            glPushMatrix();
                glScalef(1.8,1,1);
                glTranslatef(-0.2,-2.6,0);
                glutSolidSphere(0.7, 100, 100);
            glPopMatrix();
        glPopMatrix(); // Restore the previous matrix
    glPopMatrix();
}

void drawBallerinaRightShoe(void){
    //make shoe material
    GLfloat ambient[] = {0.88f, 0.54f, 0.65f, 1.0f};
    GLfloat specular[] = {0.2f, 0.2f, 0.2f, 1.0f};
    GLfloat shininess = 50.0f;

    glMaterialfv(GL_FRONT, GL_AMBIENT_AND_DIFFUSE, ambient);
    glMaterialfv(GL_FRONT, GL_SPECULAR, specular);
    glMaterialf(GL_FRONT, GL_SHININESS, shininess);
    
    glPushMatrix();
        glTranslatef(balX+1.2,balY-8.6,balZ);
        glRotatef(rightHipX,1,0,0);
        glRotatef(rightHipZ,0,0,1);
        glTranslatef(0,-6,0);
        glPushMatrix(); // Save the current matrix
        glTranslatef(0,1.125,0); // Translate the forearm back to the elbow joint
        glRotatef(rightKneeX,1,0,0); // Rotate around the elbow joint
        glRotatef(rightKneeZ,0,0,1);
        glTranslatef(0,-1.125,0); // Translate the forearm back to its original position
            glPushMatrix();
                glScalef(1.8,1,1);
                glTranslatef(0.2,-2.6,0);
                glutSolidSphere(0.7, 100, 100);
            glPopMatrix();
        glPopMatrix(); // Restore the previous matrix
    glPopMatrix();
}

void drawRightHumerus(){
    makeSkinMaterial();
    glPushMatrix();
    glTranslatef(balX+3,balY-2.125,balZ);
    glRotatef(rightShoulderX,1,0,0);
    glRotatef(rightShoulderZ,0,0,1);
    glTranslatef(0,-0.875,0);
    glScalef(1,3.5,1);
    glutSolidSphere(0.50, 100, 100);
    glPopMatrix();
}
void drawLeftHumerus(){
    makeSkinMaterial();
    glPushMatrix();
    glTranslatef(balX-3,balY-2.125,balZ);
    glRotatef(leftShoulderX,1,0,0);
    glRotatef(leftShoulderZ,0,0,1);
    glTranslatef(0,-0.875,0);
    glScalef(1,3.5,1);
    glutSolidSphere(0.50, 100, 100);
    glPopMatrix();
}
void drawRightForeArm(){
    makeSkinMaterial();
    glPushMatrix();
        glTranslatef(balX+3,balY-2.125,balZ);
        glRotatef(rightShoulderX,1,0,0);
        glRotatef(rightShoulderZ,0,0,1);
        glPushMatrix(); // Save the current matrix
        glTranslatef(0,-3.4225,0); // Translate the forearm back to the elbow joint
        glRotatef(rightElbowX,1,0,0); // Rotate around the elbow joint
        glRotatef(rightElbowZ,0,0,1);
        glTranslatef(0,-0.875,0); // Translate the forearm back to its original position
        glScalef(1,3.5,1);
        glutSolidSphere(0.50, 100, 100);
        glPopMatrix(); // Restore the previous matrix
    glPopMatrix();
}

void drawLeftForeArm(){
    makeSkinMaterial();
    glPushMatrix();
        glTranslatef(balX-3,balY-2.125,balZ);
        glRotatef(leftShoulderX,1,0,0);
        glRotatef(leftShoulderZ,0,0,1);
        glPushMatrix(); // Save the current matrix
        glTranslatef(0,-3.4225,0); // Translate the forearm back to the elbow joint
        glRotatef(leftElbowX,1,0,0); // Rotate around the elbow joint
        glRotatef(leftElbowZ,0,0,1);
        glTranslatef(0,-0.875,0); // Translate the forearm back to its original position
        glScalef(1,3.5,1);
        glutSolidSphere(0.50, 100, 100);
        glPopMatrix(); // Restore the previous matrix
    glPopMatrix();
}

void firstPosition(void){
    balY=15;
    leftShoulderX =  45;
    leftShoulderZ = -15;
    rightShoulderX= 40;
    rightShoulderZ= 15;
    leftElbowX= 95;
    leftElbowZ= -250;
    rightElbowX= -55;
    rightElbowZ= 290;
    leftHipX= 0;
    leftHipZ= 5;
    rightHipX= 0;
    rightHipZ= -5;
    leftKneeX= 0;
    leftKneeZ= 0;
    rightKneeX= 0;
    rightKneeZ= 0;
}

void secondPosition(void){
    balY=14;
    leftShoulderX= 0;
    leftShoulderZ= -85;
    rightShoulderX= 0;
    rightShoulderZ= 80;
    leftElbowX= -185;
    leftElbowZ= 165;
    rightElbowX= 0;
    rightElbowZ= -10;
    leftHipX= 0;
    leftHipZ= -15;
    rightHipX= 0;
    rightHipZ= 15;
    leftKneeX= 0;
    leftKneeZ= 0;
    rightKneeX= 0;
    rightKneeZ= 0;
}

void thirdPosition(void){
    balY=15;
    leftShoulderX= 0;
    leftShoulderZ= -80;
    rightShoulderX= 235;
    rightShoulderZ= 165;
    leftElbowX= -175;
    leftElbowZ= 185;
    rightElbowX= -5;
    rightElbowZ= 50;
    leftHipX= 5;
    leftHipZ= 5;
    rightHipX= -5;
    rightHipZ= -5;
    leftKneeX= 0;
    leftKneeZ= 0;
    rightKneeX= 0;
    rightKneeZ= 0;
}

void fourthPosition(void){
    balY=13.5;
    leftShoulderX= 100;
    leftShoulderZ= 10;
    rightShoulderX= 50;
    rightShoulderZ= -25;
    leftElbowX= 0;
    leftElbowZ= 0;
    rightElbowX= 0;
    rightElbowZ= 0;
    leftHipX= 30;
    leftHipZ= 0;
    rightHipX= -30;
    rightHipZ= 5;
    leftKneeX= 0;
    leftKneeZ= 0;
    rightKneeX= 0;
    rightKneeZ= 0;
}

void fifthPosition(void){
    balY=15;
    leftShoulderX= 155;
    leftShoulderZ= -20;
    rightShoulderX= 145;
    rightShoulderZ= 15;
    leftElbowX= 160;
    leftElbowZ= -225;
    rightElbowX= 25;
    rightElbowZ= -35;
    leftHipX= 0;
    leftHipZ= 15;
    rightHipX= 10;
    rightHipZ= -10;
    leftKneeX= 0;
    leftKneeZ= 0;
    rightKneeX= 0;
    rightKneeZ= 0;
}

void sauteDeChat(void){
    startSaute = true;
}
int sauteStep = 0;
int sauteTime = 0;
void animateSauteDeChat(int someValue){
    if(startSaute == true ){
        turnAngle = 90;
        if(sauteStep == 0 && sauteTime == 2){
            firstPosition();
            sauteStep = 1;
            sauteTime = 0;
            cout << "firstLeg" << endl;
        }
        else if(sauteStep == 1 && sauteTime == 4){
            leftShoulderX= 45;
            leftShoulderZ= -15;
            rightShoulderX= 40;
            rightShoulderZ= 15;
            leftElbowX= 95;
            leftElbowZ= -250;
            rightElbowX= -55;
            rightElbowZ= 290;
            leftHipX= 0;
            leftHipZ= 5;
            rightHipX= 40;
            rightHipZ= -5;
            leftKneeX= 0;
            leftKneeZ= 0;
            rightKneeX= -15;
            rightKneeZ= 0;
            sauteStep = 2;
            sauteTime = 0;
            cout << "secondLeg" << endl;
        }
        else if(sauteStep == 2 && sauteTime == 4){
            balY-=1;
            leftShoulderX= 100;
            leftShoulderZ= 10;
            rightShoulderX= 50;
            rightShoulderZ= -25;
            leftElbowX= 0;
            leftElbowZ= 0;
            rightElbowX= 0;
            rightElbowZ= 0;
            leftHipX= 65;
            leftHipZ= 0;
            rightHipX= 0;
            rightHipZ= 5;
            leftKneeX= -35;
            leftKneeZ= 0;
            rightKneeX= 5;
            rightKneeZ= 0;
            sauteStep = 3;
            sauteTime = 0;
            cout << "thirdleg" << endl;
        }
        else if(sauteStep == 3 && sauteTime ==4){
            balY+=3;
            balX-=1;
            leftShoulderX= 140;
            leftShoulderZ= 10;
            rightShoulderX= 70;
            rightShoulderZ= -25;
            leftElbowX= 0;
            leftElbowZ= 0;
            rightElbowX= 0;
            rightElbowZ= 0;
            leftHipX= 80;
            leftHipZ= 0;
            rightHipX= -80;
            rightHipZ= 5;
            leftKneeX= 0;
            leftKneeZ= 0;
            rightKneeX= 0;
            rightKneeZ= 0;
            sauteStep = 4;
            sauteTime = 0;
            cout << "fourth leg" << endl;
        }
        else if(sauteStep == 4 && sauteTime == 4){
            balY+=1;
            balX-=2;
            leftShoulderX= 100;
            leftShoulderZ= 10;
            rightShoulderX= 50;
            rightShoulderZ= -25;
            leftElbowX= 0;
            leftElbowZ= 0;
            rightElbowX= 0;
            rightElbowZ= 0;
            leftHipX= 0;
            leftHipZ= 0;
            rightHipX= -100;
            rightHipZ= 5;
            leftKneeX= 0;
            leftKneeZ= 0;
            rightKneeX= 0;
            rightKneeZ= 0;
            sauteStep = 5;
            sauteTime = 0;
            cout << "fifth leg" << endl;
        }
        else if(sauteStep == 5 && sauteTime == 4){
            balY-=1;
            balX-=1;
            leftShoulderX= 100;
            leftShoulderZ= 10;
            rightShoulderX= 50;
            rightShoulderZ= -25;
            leftElbowX= 0;
            leftElbowZ= 0;
            rightElbowX= 0;
            rightElbowZ= 0;
            leftHipX= 0;
            leftHipZ= 0;
            rightHipX= -100;
            rightHipZ= 5;
            leftKneeX= 0;
            leftKneeZ= 0;
            rightKneeX= 0;
            rightKneeZ= 0;
            sauteStep = 6;
            sauteTime = 0;
            cout << "sixthLeg" << endl;
        }
        else if(sauteStep == 6 && sauteTime ==4){
            balY-=2;
            balX-=1;
            leftShoulderX= 45;
            leftShoulderZ= -15;
            rightShoulderX= 40;
            rightShoulderZ= 15;
            leftElbowX= 95;
            leftElbowZ= -250;
            rightElbowX= -55;
            rightElbowZ= 290;
            leftHipX= -25;
            leftHipZ= 5;
            rightHipX= 20;
            rightHipZ= -5;
            leftKneeX= 0;
            leftKneeZ= 0;
            rightKneeX= 0;
            rightKneeZ= 0;
            sauteStep = 7;
            sauteTime = 0;
            cout << "seventh leg" << endl;
        }
        else if(sauteStep == 7 && sauteTime ==4){
            firstPosition();
            sauteStep = 0;
            sauteTime = 0;
            if(sauteAway == false){
                startSaute = false;
                balX = 0;
                balY = 15;
                balZ = 30;
                turnAngle = 0;
            }
            else if(sauteAway == true){
                cout << balX << endl;
                if(balX < -15){
                    lightOn = false;
                    if(balX < -30){
                        sauteStep = 0;
                        sauteTime = 0;
                        startSaute = false;
                        turnAngle = -90;
                        firstPosition();
                    }
                }
                else{
                    lightOn = true;
                }
            }
            cout << "eigth leg" << endl;
        }
        sauteTime++;
        redisplay();
    }
    glutTimerFunc(100,animateSauteDeChat,1);
}

void pasDeChat(void){
    startChat = true;
}

int chatStep = 0;
int chatTime = 0;
void animatePasDeChat(int someValue){
    if(startChat == true){
        if(chatStep == 0 && chatTime == 5){
            thirdPosition();
            chatTime = 0;
            chatStep = 1;
            cout << "firstLeg" << endl;
        }
        else if(chatStep == 1 && chatTime == 5){
            leftShoulderX= 0;
            leftShoulderZ= -80;
            rightShoulderX= 235;
            rightShoulderZ= 165;
            leftElbowX= -175;
            leftElbowZ= 185;
            rightElbowX= -5;
            rightElbowZ= 50;
            leftHipX= -15;
            leftHipZ= -5;
            rightHipX= -5;
            rightHipZ= 55;
            leftKneeX= -715;
            leftKneeZ= 0;
            rightKneeX= 50;
            rightKneeZ= -155;
            chatTime = 0;
            chatStep = 2;
            cout << "secondleg" << endl;
        }
        else if(chatStep == 2 && chatTime == 2){
            balY+=3;
            leftShoulderX= 0;
            leftShoulderZ= -80;
            rightShoulderX= 235;
            rightShoulderZ= 165;
            leftElbowX= -175;
            leftElbowZ= 185;
            rightElbowX= -5;
            rightElbowZ= 50;
            leftHipX= 55;
            leftHipZ= -45;
            rightHipX= -5;
            rightHipZ= 55;
            leftKneeX= -120;
            leftKneeZ= -290;
            rightKneeX= 65;
            rightKneeZ= -155;
            chatTime = 0;
            chatStep = 3;
            cout << "thirdLeg" << endl;
        }
        else if(chatStep == 3 && chatTime == 2){
            balY-=3;
            leftShoulderX= 0;
            leftShoulderZ= -80;
            rightShoulderX= 235;
            rightShoulderZ= 165;
            leftElbowX= -175;
            leftElbowZ= 185;
            rightElbowX= -5;
            rightElbowZ= 50;
            leftHipX= 55;
            leftHipZ= -45;
            rightHipX= -5;
            rightHipZ= -5;
            leftKneeX= -120;
            leftKneeZ= -290;
            rightKneeX= 0;
            rightKneeZ= 0;
            chatTime = 0;
            chatStep = 4;
            cout << "fourthLeg" << endl;
        }
        else if(chatStep == 4 && chatTime == 2){
            thirdPosition();
            chatTime = 0;
            chatStep = 0;
            startChat = false;
        }
        chatTime++;
        redisplay();
        
    }
    glutTimerFunc(100,animatePasDeChat,1);
}

void pique(void){
    startPique = true;
}

int piqueTime = 0;
int piqueLeg = 0;

void animatePique(int someValue){
    if(startPique == true){
        if(piqueLeg == 0 && piqueTime == 2){
            firstPosition();
            piqueTime = 0;
            piqueLeg = 1;
        }
        else if(piqueLeg == 1 && piqueTime == 2){
            leftShoulderX= 0;
            leftShoulderZ= -80;
            rightShoulderX= 235;
            rightShoulderZ= 165;
            leftElbowX= -175;
            leftElbowZ= 185;
            rightElbowX= -5;
            rightElbowZ= 50;
            leftHipX= 30;
            leftHipZ= 5;
            rightHipX= 0;
            rightHipZ= -5;
            leftKneeX= 0;
            leftKneeZ= 0;
            rightKneeX= 0;
            rightKneeZ= 0;
            piqueTime = 0;
            piqueLeg = 2;
        }
        else if(piqueLeg == 2 && piqueTime == 2){
            turnAngle = 45;
            leftShoulderX= 0;
            leftShoulderZ= -80;
            rightShoulderX= 235;
            rightShoulderZ= 165;
            leftElbowX= -175;
            leftElbowZ= 185;
            rightElbowX= -5;
            rightElbowZ= 50;
            leftHipX= 35;
            leftHipZ= 5;
            rightHipX= 0;
            rightHipZ= 15;
            leftKneeX= 0;
            leftKneeZ= 0;
            rightKneeX= 10;
            rightKneeZ= -20;
            piqueTime = 0;
            piqueLeg = 3;
        }
        else if(piqueLeg == 3 && piqueTime == 2){
            balX-=5;
            leftShoulderX= 45;
            leftShoulderZ= -15;
            rightShoulderX= 40;
            rightShoulderZ= 15;
            leftElbowX= 95;
            leftElbowZ= -250;
            rightElbowX= -55;
            rightElbowZ= 290;
            leftHipX= 0;
            leftHipZ= 5;
            rightHipX= 0;
            rightHipZ= 55;
            leftKneeX= 0;
            leftKneeZ= 0;
            rightKneeX= 0;
            rightKneeZ= -130;
            piqueTime = 0;
            piqueLeg = 4;
        }
        else if(piqueLeg == 4 && turnAngle<405){
            turnAngle+=30;
        }
        else if(piqueLeg == 4 && turnAngle>=405){
            piqueTime =0;
            piqueLeg = 5;
        }
        else if(piqueLeg == 5 && piqueTime == 2){
            turnAngle = 45;
            leftShoulderX= 0;
            leftShoulderZ= -80;
            rightShoulderX= 235;
            rightShoulderZ= 165;
            leftElbowX= -175;
            leftElbowZ= 185;
            rightElbowX= -5;
            rightElbowZ= 50;
            leftHipX= 35;
            leftHipZ= 5;
            rightHipX= 0;
            rightHipZ= 15;
            leftKneeX= 0;
            leftKneeZ= 0;
            rightKneeX= 10;
            rightKneeZ= -20;
            piqueTime = 0;
            piqueLeg = 6;
        }
        else if(piqueLeg == 6 && piqueTime ==2){
            balX+=5;
            turnAngle = 0;
            piqueLeg = 0;
            piqueTime = 0;
            startPique = false;
            firstPosition();
        }
        //turn +360 degrees;
        piqueTime++;
        redisplay();
    }
    
    glutTimerFunc(100,animatePique,1);
}


void pirouette(void){
    startTurn = true;
}

int turnTime = 0;
int turnLeg = 0;
void animatePirouette(int someValue){
    if(startTurn == true && turnAngle > -360){
        if( turnLeg == 0 && turnTime == 10){
            balY=13.5;
            fourthPosition();
            leftShoulderX= 0;
            leftShoulderZ= -80;
            rightShoulderX= 235;
            rightShoulderZ= 165;
            leftElbowX= -175;
            leftElbowZ= 185;
            rightElbowX= -5;
            rightElbowZ= 50;
            turnTime = 0;
            turnLeg = 1;
            cout << "leg 1" << endl;
        }
        else if(turnLeg == 1 && turnAngle > -345){
            balY=15;
            balZ=28;
            leftShoulderX =  45;
            leftShoulderZ = -15;
            rightShoulderX= 40;
            rightShoulderZ= 15;
            leftElbowX= 95;
            leftElbowZ= -250;
            rightElbowX= -55;
            rightElbowZ= 290;
            leftHipX= 5;
            leftHipZ= 0;
            rightHipX= 20;
            rightHipZ= 55;
            leftKneeX= 0;
            leftKneeZ= 0;
            rightKneeX= 0;
            rightKneeZ= -135;
            turnAngle-=15;
            turnTime = 0;
            cout << "leg 2" << endl;
        }
        else if(turnLeg == 1){
            turnAngle=0;
            balY=13.5;
            fourthPosition();
            leftShoulderX= 0;
            leftShoulderZ= -80;
            rightShoulderX= 235;
            rightShoulderZ= 165;
            leftElbowX= -175;
            leftElbowZ= 185;
            rightElbowX= -5;
            rightElbowZ= 50;
            turnTime = 0;
            turnLeg = 0;
            startTurn = false;
            cout << "leg 3" << endl;
        }
       
        turnTime++;
        redisplay();
    }
    
    glutTimerFunc(25,animatePirouette,1);
}

void reset(void){
    leftShoulderX =  0;
    leftShoulderZ = 0;
    rightShoulderX= 0;
    rightShoulderZ= 0;
    leftElbowX= 0;
    leftElbowZ= 0;
    rightElbowX= 0;
    rightElbowZ= 0;
    leftHipX= 0;
    leftHipZ= 0;
    rightHipX= 0;
    rightHipZ= 0;
    leftKneeX= 0;
    leftKneeZ= 0;
    rightKneeX= 0;
    rightKneeZ= 0;
    turnAngle = 0;
    balX = 0;
    balY = 15;
    balZ = 30;
    lightOn = true;
}

void ballerina(void){
    //right leg
    drawBallerinaRightThigh();
    drawBallerinaRightCalf();
    drawBallerinaRightShoe();
    
    //left leg
    drawBallerinaLeftThigh();
    drawBallerinaLeftCalf();
    drawBallerinaLeftShoe();
    
    //right arm
    drawRightHumerus();
    drawRightForeArm();
    
    //left arm
    drawLeftHumerus();
    drawLeftForeArm();
}


// Drawing routine.
void drawSceneStage(void)
{
    glutSetWindow(stage);
    glClear (GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    glLoadIdentity();
    gluLookAt(meX,meY,meZ,meX+sin(angle*PI/180),meY,meZ + cos(angle*PI/180),0,1,0);
    if(isPicking){
        glDisable(GL_LIGHTING);
        glColor3f(1,0,0);//red
        drawBallerinaDress();
        getID(xClick,yClick);
        isPicking = false;
        glEnable(GL_LIGHTING);
    }
    else{
        choreography();
        drawCurtainBackdrop();
        drawStage();
        drawCurtain();
        glPushMatrix();
        glTranslatef(balX,balY,balZ);
        glRotatef(turnAngle,0,1,0);
        glTranslatef(-balX,-balY,-balZ);
        drawBallerinaHead();
        drawBallerinaDress();
        ballerina();
        glPopMatrix();
        glFlush();
        glutSwapBuffers();
    }
}


void specialKeyInput(int key, int x, int y)
{
   
    colisionDetection();
    if(jointId == 8){
        switch(key){
            case GLUT_KEY_UP: //forward
                if(moveX){
                    meZ+=stepsize*cos(angle * (PI/180));
                }
                if(moveZ){
                    meX+=stepsize*sin(angle* (PI/180)) ;
                }
                break;
            case GLUT_KEY_DOWN: //back
                if(moveX){
                    meZ-=stepsize*cos(angle * (PI/180));
                }
                if(moveZ){
                    meX-=stepsize*sin(angle* (PI/180));
                }
                break;
            case GLUT_KEY_RIGHT: //turn right
                angle-=turnsize;
                break;
            case GLUT_KEY_LEFT: //turn left
                angle+=turnsize;
                break;
        }//end switch
        redisplay();
    }
    else if(jointId == 0){
        switch(key){
            case GLUT_KEY_UP: //forward
                leftShoulderX+=5;
                break;
            case GLUT_KEY_DOWN: //back
                leftShoulderX-=5;
                break;
            case GLUT_KEY_RIGHT: //turn right
                leftShoulderZ-=5;
                break;
            case GLUT_KEY_LEFT: //turn left
                leftShoulderZ+=5;
                break;
        }//end switch
    }
    else if(jointId == 1){
        switch(key){
            case GLUT_KEY_UP: //forward
                rightShoulderX+=5;
                break;
            case GLUT_KEY_DOWN: //back
                rightShoulderX-=5;
                break;
            case GLUT_KEY_RIGHT: //turn right
                rightShoulderZ-=5;
                break;
            case GLUT_KEY_LEFT: //turn left
                rightShoulderZ+=5;
                break;
        }//end switch
        redisplay();
    }
    else if(jointId == 2){
        switch(key){
            case GLUT_KEY_UP: //forward
                leftElbowX+=5;
                break;
            case GLUT_KEY_DOWN: //back
                leftElbowZ-=5;
                break;
            case GLUT_KEY_RIGHT: //turn right
                leftElbowX-=5;
                break;
            case GLUT_KEY_LEFT: //turn left
                leftElbowZ+=5;
                break;
        }//end switch
        redisplay();
    }
        else if(jointId == 3){
            switch(key){
                case GLUT_KEY_UP: //forward
                    rightElbowX+=5;
                    break;
                case GLUT_KEY_DOWN: //back
                    rightElbowZ-=5;
                    break;
                case GLUT_KEY_RIGHT: //turn right
                    rightElbowX-=5;
                    break;
                case GLUT_KEY_LEFT: //turn left
                    rightElbowZ+=5;
                    break;
            }//end switch
            redisplay();
    }
        else if(jointId == 4){
            switch(key){
                case GLUT_KEY_UP: //forward
                    leftHipX+=5;
                    break;
                case GLUT_KEY_DOWN: //back
                    leftHipX-=5;
                    break;
                case GLUT_KEY_RIGHT: //turn right
                    leftHipZ-=5;
                    break;
                case GLUT_KEY_LEFT: //turn left
                    leftHipZ+=5;
                    break;
            }//end switch
            redisplay();
    }
        else if(jointId == 5){
            switch(key){
                case GLUT_KEY_UP: //forward
                    rightHipX+=5;
                    break;
                case GLUT_KEY_DOWN: //back
                    rightHipX-=5;
                    break;
                case GLUT_KEY_RIGHT: //turn right
                    rightHipZ-=5;
                    break;
                case GLUT_KEY_LEFT: //turn left
                    rightHipZ+=5;
                    break;
            }//end switch
            redisplay();
    }
        else if(jointId == 6){
            switch(key){
                case GLUT_KEY_UP: //forward
                    leftKneeX+=5;
                    break;
                case GLUT_KEY_DOWN: //back
                    leftKneeX-=5;
                    break;
                case GLUT_KEY_RIGHT: //turn right
                    leftKneeZ-=5;
                    break;
                case GLUT_KEY_LEFT: //turn left
                    leftKneeZ+=5;
                    break;
            }//end switch
            redisplay();
    }
        else if(jointId == 7){
            switch(key){
                case GLUT_KEY_UP: //forward
                    rightKneeX+=5;
                    break;
                case GLUT_KEY_DOWN: //back
                    rightKneeX-=5;
                    break;
                case GLUT_KEY_RIGHT: //turn right
                    rightKneeZ-=5;
                    break;
                case GLUT_KEY_LEFT: //turn left
                    rightKneeZ+=5;
                    break;
            }//end switch
            redisplay();
    }
    redisplay();
    
}

// Routine to output interaction instructions to the C++ window.
void printInteraction(void)
{
    cout << "Interaction:" << endl;
}

// Keyboard input processing routine.
/*
 [0] = left shoulder
 [1] = right shoulder
 [2] = left elbow
 [3] = right elbow
 [4] = left hip
 [5] = right hip
 [6] = left knee
 [7] = right knee
 [8] = move eye
 */

void keyInput(unsigned char key, int x, int y)
{
    switch(key)
    {
        case 'w':
            cout << "saute away" << endl;
            sauteAway = true;
            sauteDeChat();
            redisplay();
            break;
        case 's':
            cout << "selected left shoulder" << endl;
            jointId = 0;
            break;
        case 'S':
            cout << "selected right shoulder" << endl;
            jointId = 1;
            break;
        case 'e':
            cout << "selected left elbow" << endl;
            jointId = 2;
            break;
        case 'E':
            cout << "selected right elbow" << endl;
            jointId = 3;
            break;
        case 'h':
            cout << "selected left hip" << endl;
            jointId = 4;
            break;
        case 'H':
            cout << "selected right hip" << endl;
            jointId = 5;
            break;
        case 'k':
            cout << "selected left knee" << endl;
            jointId = 6;
            break;
        case 'K':
            cout << "selected right knee" << endl;
            jointId = 7;
            break;
        case 'm':
            cout << "move eye view" << endl;
            jointId = 8;
            redisplay();
            break;
        case 'p':
            cout << "leftShoulderX= " << leftShoulderX << ";" << endl;
            cout << "leftShoulderZ= " << leftShoulderZ << ";" << endl;
            cout << "rightShoulderX= " << rightShoulderX << ";" <<endl;
            cout << "rightShoulderZ= " << rightShoulderZ << ";" <<endl;
            cout << "leftElbowX= " << leftElbowX << ";" <<endl;
            cout << "leftElbowZ= " << leftElbowZ << ";" <<endl;
            cout << "rightElbowX= " << rightElbowX << ";" <<endl;
            cout << "rightElbowZ= " << rightElbowZ << ";" <<endl;
            cout << "leftHipX= " << leftHipX << ";" <<endl;
            cout << "leftHipZ= " << leftHipZ << ";" <<endl;
            cout << "rightHipX= " << rightHipX << ";" <<endl;
            cout << "rightHipZ= " << rightHipZ << ";" <<endl;
            cout << "leftKneeX= " << leftKneeX << ";" <<endl;
            cout << "leftKneeZ= " << leftKneeZ << ";" <<endl;
            cout << "rightKneeX= " << rightKneeX << ";" <<endl;
            cout << "rightKneeZ= " << rightKneeZ << ";" <<endl;
            cout << "" << endl;
            cout << "meX = " << meX << endl;
            cout << "meZ = " << meZ << endl;
            break;
        case 't':
            first = 0;
            second = 0;
            third = 0;
            forth = 0;
            fifth = 0;
            cout << "pirouette" << endl;
            pirouette();
            redisplay();
            break;
        case 'T':
            first = 0;
            second = 0;
            third = 0;
            forth = 0;
            fifth = 0;
            cout << "pique" << endl;
            pique();
            redisplay();
            break;
        case 'c':
            first = 0;
            second = 0;
            third = 0;
            forth = 0;
            fifth = 0;
            cout << "pas de chat" << endl;
            pasDeChat();
            redisplay();
            break;
        case 'j':
            first = 0;
            second = 0;
            third = 0;
            forth = 0;
            fifth = 0;
            cout << "saute de chat" << endl;
            sauteAway= false;
            sauteDeChat();
            redisplay();
            break;
        case '0':
            first = 0;
            second = 0;
            third = 0;
            forth = 0;
            fifth = 0;
            danceRandom = false;
            reset();
            redisplay();
            break;
        case '1':
            first = 1;
            second = 0;
            third = 0;
            forth = 0;
            fifth = 0;
            firstPosition();
            cout << "first position" << endl;
            redisplay();
            break;
        case '2':
            first = 0;
            second = 1;
            third = 0;
            forth = 0;
            fifth = 0;
            secondPosition();
            cout << "second postition" << endl;
            redisplay();
            break;
        case '3':
            first = 0;
            second = 0;
            third = 1;
            forth = 0;
            fifth = 0;
            thirdPosition();
            cout << "third position" << endl;
            redisplay();
            break;
        case '4':
            first = 0;
            second = 0;
            third = 0;
            forth = 1;
            fifth = 0;
            fourthPosition();
            cout << "fourth position" << endl;
            redisplay();
            break;
        case '5':
            first = 0;
            second = 0;
            third = 0;
            forth = 0;
            fifth = 1;
            fifthPosition();
            cout << "fifth position" << endl;
            redisplay();
            break;
        case 27:
            exit(0);
            break;
        default:
            break;
    }
}



void generalMenu(int id){
    if(id==1) exit(0);
}

void dressColorMenu(int id){
    switch(id){
        case 7:
            cout << "green" << endl;
            dressColor[0] = 0.78;
            dressColor[1] = 0.68;
            dressColor[2] = 0.84;
            
            break;
        case 8:
            cout << "black" << endl;
            dressColor[0] = 0;
            dressColor[1] = 0;
            dressColor[2] = 0;
            break;
        case 9:
            cout << "blue" << endl;
            dressColor[0] = 0;
            dressColor[1] = 0;
            dressColor[2] = 0.5;
            break;
    }
    redisplay();
}

void hairColorMenu(int id){
    switch(id){
        case 2:
            cout << "black" << endl;
            hairColor[0] = 0.0f;
            hairColor[1] = 0.0f;
            hairColor[2] = 0.0f;
            
            break;
        case 3:
            cout << "brown" << endl;
            hairColor[0] = 0.35f;
            hairColor[1] = 0.18f;
            hairColor[2] = 0.11f;
            break;
        case 4:
            cout << "blonde" << endl;
            hairColor[0] = 1.0f;
            hairColor[1] = 1.0f;
            hairColor[2] = 0.4f;
            break;
        case 5:
            cout << "red" << endl;
            hairColor[0] = 0.8f;
            hairColor[1] = 0.0f;
            hairColor[2] = 0.0f;
            break;
        case 6:
            cout << "silver" << endl;
            hairColor[0] = 0.65f;
            hairColor[1] = 0.65f;
            hairColor[2] = 0.65f;
            break;
    }
    redisplay();
}

void skinColorMenu(int id){
    switch(id){
        case 2:
            cout << "light" << endl;
            skinColor[0] = 0.92f;
            skinColor[1] = 0.78f;
            skinColor[2] = 0.67f;
            
            break;
        case 3:
            cout << "fair" << endl;
            skinColor[0] = 0.85f;
            skinColor[1] = 0.70f;
            skinColor[2] = 0.60f;
            break;
        case 4:
            cout << "medium" << endl;
            skinColor[0] = 0.72f;
            skinColor[1] = 0.52f;
            skinColor[2] = 0.43f;
            break;
        case 5:
            cout << "tan" << endl;
            skinColor[0] = 0.59f;
            skinColor[1] = 0.41f;
            skinColor[2] = 0.31f;
            break;
        case 6:
            cout << "dark" << endl;
            skinColor[0] = 0.39f;
            skinColor[1] = 0.29f;
            skinColor[2] = 0.21f;
            break;
    }
    redisplay();
}

void generateGeneralMenu(){
    // The sub-menu is created first (because it should be visible when the top
    // menu is created): its callback function is registered and menu entries added.
    int skinColorSub;
    skinColorSub = glutCreateMenu(skinColorMenu);
    glutAddMenuEntry("light",2);
    glutAddMenuEntry("fair",3);
    glutAddMenuEntry("medium",4);
    glutAddMenuEntry("tan",5);
    glutAddMenuEntry("dark",6);
    
    int hairColorSub;
    hairColorSub = glutCreateMenu(hairColorMenu);
    glutAddMenuEntry("black",2);
    glutAddMenuEntry("brown",3);
    glutAddMenuEntry("blonde",4);
    glutAddMenuEntry("red",5);
    glutAddMenuEntry("silver",6);
    
    
    int dressColorSub;
    dressColorSub = glutCreateMenu(dressColorMenu);
    glutAddMenuEntry("green",7);
    glutAddMenuEntry("black",8);
    glutAddMenuEntry("blue",9);
   
    // The top menu is created: its callback function is registered and menu entries,
    // including a submenu, added.
    glutCreateMenu(generalMenu);
    glutAddSubMenu("Dress Color", dressColorSub);
    glutAddSubMenu("Hair Color", hairColorSub);
    glutAddSubMenu("Skin Color", skinColorSub);
    glutAddMenuEntry("Quit",1);

    // The menu is attached to a mouse button.
    glutAttachMenu(GLUT_RIGHT_BUTTON);
}
void pickFunctionBallerina(int button, int state, int x, int y){
    isPicking=true;
    xClick=x;
    yClick=height-y;
    cout<<"In pickFunction ballerina"<<endl;
    cout<<"xClick="<<xClick<<" yClick="<<yClick<<endl;
    redisplay();
}

void pickFunction(int button, int state, int x, int y)
{
    if (button == GLUT_LEFT_BUTTON && state == GLUT_DOWN);
    {
        //isPicking=true;
        xClick=x;
        yClick=height-y;
        cout<<"In pickFunction"<<endl;
        cout<<"xClick="<<xClick<<" yClick="<<yClick<<endl;
        if(xClick > 96 && xClick<104 && yClick<384 && yClick>376){
            first = 1;
            second = 0;
            third = 0;
            forth = 0;
            fifth = 0;
            firstPosition();
            cout << "first position" << endl;
        }
        else if(xClick > 96 && xClick<104 && yClick<334 && yClick>326){
            first = 0;
            second = 1;
            third = 0;
            forth = 0;
            fifth = 0;
            secondPosition();
            cout << "second position" << endl;
        }
        else if(xClick > 96 && xClick<104 && yClick<284 && yClick>276){
            first = 0;
            second = 0;
            third = 1;
            forth = 0;
            fifth = 0;
            thirdPosition();
            cout << "third position" << endl;
        }
        else if(xClick > 96 && xClick<104 && yClick<234 && yClick>226){
            first = 0;
            second = 0;
            third = 0;
            forth = 1;
            fifth = 0;
            fourthPosition();
            cout << "fourth position" << endl;
        }
        else if(xClick > 96 && xClick<104 && yClick<184 && yClick>176){
            first = 0;
            second = 0;
            third = 0;
            forth = 0;
            fifth = 1;
            fifthPosition();
            cout << "fifth position" << endl;
        }
        else if(xClick > 246 && xClick<254 && yClick<384 && yClick>376){
            first = 0;
            second = 0;
            third = 0;
            forth = 0;
            fifth = 0;
            pirouette();
            cout << "pirouette" << endl;
        }
        else if(xClick > 246 && xClick<254 && yClick<334 && yClick>326){
            first = 0;
            second = 0;
            third = 0;
            forth = 0;
            fifth = 0;
            pasDeChat();
            cout << "pas de chat" << endl;
        }
        else if(xClick > 246 && xClick<254 && yClick<284 && yClick>276){
            first = 0;
            second = 0;
            third = 0;
            forth = 0;
            fifth = 0;
            sauteAway = false;
            sauteDeChat();
            cout << "saute de chat" << endl;
        }
        else if(xClick > 246 && xClick<254 && yClick<234 && yClick>226){
            first = 0;
            second = 0;
            third = 0;
            forth = 0;
            fifth = 0;
            pique();
            cout << "pique turn" << endl;
        }
        redisplay();
    }
}


// Main routine.
int main(int argc, char **argv)
{
    
    printInteraction();
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_SINGLE | GLUT_RGB | GLUT_DEPTH);
    // Second top-level window definition.
    
    //stage window
    glutInitWindowSize(500, 500);
    glutInitWindowPosition(100, 100);
    stage = glutCreateWindow("break a leg!");
    setupStage();
    glutDisplayFunc(drawSceneStage);
    glutReshapeFunc(resizeStage);
    
    //shared by both
    glutKeyboardFunc(keyInput);
    glutSpecialFunc(specialKeyInput);
    glutMouseFunc(pickFunctionBallerina);
    //glutMouseFunc(pickFunction); // Mouse control.
    generateGeneralMenu();
    
    //mouse-click selection window
   glutInitWindowSize(500, 500);
   glutInitWindowPosition(600, 100);
   selection = glutCreateWindow("choreography");
   setupSelection();
   glutDisplayFunc(drawSceneSelection);
   glutReshapeFunc(resizeSelection);
    
    //shared by both
    glutKeyboardFunc(keyInput);
    glutSpecialFunc(specialKeyInput);
    glutMouseFunc(pickFunction); // Mouse control.
    generateGeneralMenu();
    
 
   
    glutTimerFunc(5,animatePirouette,1);
    glutTimerFunc(5,animatePasDeChat,1);
    glutTimerFunc(5,animateSauteDeChat,1);
    glutTimerFunc(5, animatePique, 1);
    //glutTimerFunc(5,choreography,1);
    glutMainLoop();
    return 0;
}
